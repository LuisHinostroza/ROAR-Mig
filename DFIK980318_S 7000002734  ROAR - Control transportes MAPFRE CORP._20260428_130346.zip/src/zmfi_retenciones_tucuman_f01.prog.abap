*&---------------------------------------------------------------------*
*&      Form  VALIDATE_RETEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_reten .

  CONSTANTS: lc_land1 TYPE land1 VALUE 'AR',
             lc_witht TYPE witht VALUE 'RT'.

  DATA: lv_wt_withcd TYPE wt_withcd,
        lv_message TYPE string.

  IF s_witht-low <> lc_witht AND  s_witht-low IS NOT INITIAL.
    CONCATENATE 'El tipo de Retención debe ser' lc_witht INTO lv_message SEPARATED BY space.
    MESSAGE lv_message TYPE 'E' DISPLAY LIKE 'E'.
  ELSE.
    IF p_withcd IS NOT INITIAL.
      SELECT SINGLE wt_withcd
        FROM t059z
        INTO lv_wt_withcd
        WHERE land1     = lc_land1 AND
              witht     = lc_witht AND
              wt_withcd = p_withcd.
      IF sy-subrc <> 0.
        MESSAGE 'El indicador de Retención no es correcto' TYPE 'E' DISPLAY LIKE 'E'.
      ENDIF.

    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_RETEN
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  PERFORM cabecera_documentos.
  PERFORM documentos_compensados.
  PERFORM clase_documentos.
  PERFORM maestro_proveedores.
ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM cabecera_documentos .

  SELECT bukrs belnr gjahr budat brnch bktxt
  FROM bkpf
  INTO TABLE lt_bkpf
  WHERE bukrs EQ p_bukrs AND
        belnr IN s_belnr AND
        gjahr IN s_gjahr AND
        blart IN s_blart AND
        budat IN s_budat AND
        xstov NE lc_charx.
  IF sy-subrc EQ 0.
    IF NOT p_withcd IS INITIAL.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht      AND
            wt_withcd EQ p_withcd.
    ELSE.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht.
    ENDIF.
  ENDIF.

ENDFORM.                    " CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM documentos_compensados .

  IF NOT lt_with_item[] IS INITIAL.

    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
    FROM bsak
    INTO TABLE lt_bsak
    FOR ALL ENTRIES IN lt_with_item
    WHERE bukrs EQ p_bukrs            AND
          augbl EQ lt_with_item-belnr AND
          belnr NE lt_with_item-belnr AND
          augdt EQ lt_with_item-augdt.
    IF sy-subrc EQ 0.
      IF NOT p_withcd IS INITIAL.
        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
        FROM with_item
        INTO TABLE lt_with_item2
        FOR ALL ENTRIES IN lt_bsak
        WHERE bukrs     EQ p_bukrs AND
              belnr     EQ lt_bsak-belnr AND
              gjahr     EQ lt_bsak-gjahr AND
              witht     IN s_witht       AND
              wt_withcd EQ p_withcd.
      ELSE.
        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
        FROM with_item
        INTO TABLE lt_with_item2
        FOR ALL ENTRIES IN lt_bsak
        WHERE bukrs     EQ p_bukrs AND
              belnr     EQ lt_bsak-belnr AND
              gjahr     EQ lt_bsak-gjahr AND
              witht     IN s_witht.
      ENDIF.
    ENDIF.
*    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
*      FROM bsak
*      INTO TABLE lt_bsak
*      FOR ALL ENTRIES IN lt_with_item
*      WHERE bukrs EQ p_bukrs            AND
*            belnr EQ lt_with_item-belnr AND
*            gjahr EQ lt_with_item-gjahr.
  ENDIF.

ENDFORM.                    " DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*&      Form  MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM maestro_proveedores .
  IF NOT lt_bsak[] IS INITIAL.
    SELECT lifnr name1 adrnr stcd1 stcd2 fityp stcdt
    FROM lfa1
    INTO TABLE lt_lfa1
    FOR ALL ENTRIES IN lt_bsak
    WHERE lifnr EQ lt_bsak-lifnr AND
          land1 EQ lc_ar.
    IF sy-subrc EQ 0.
      SELECT addrnumber city1 post_code1 street house_num1 region
      FROM adrc
      INTO TABLE lt_adrc
      FOR ALL ENTRIES IN lt_lfa1
      WHERE addrnumber = lt_lfa1-adrnr.
      IF sy-subrc EQ 0.
        SELECT bland bezei
        FROM t005u
        INTO TABLE lt_t005u
        FOR ALL ENTRIES IN lt_adrc
        WHERE spras = 'S'    AND
              land1 = lc_ar AND
              bland = lt_adrc-region.
      ENDIF.
    ENDIF.
  ENDIF.
ENDFORM.                    " MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*&      Form  GET_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_alv .

  LOOP AT lt_bsak INTO ls_bsak.

    CLEAR:ls_lfa1, ls_report_alv,
          ls_with_item, ls_with_item2.

    ls_report_alv-belnr     = ls_bsak-belnr.              "1
    ls_report_alv-xblnr     = ls_bsak-xblnr.              "2
    ls_report_alv-wt_acco   = ls_bsak-lifnr.              "3
    ls_report_alv-gjahr     = ls_bsak-gjahr.              "5
    ls_report_alv-dmbtr     = ls_bsak-dmbtr.              "12
    ls_report_alv-letra     = ls_bsak-xblnr+4(1).         "8

    READ TABLE lt_t003_i INTO ls_t003_i
         WITH KEY blart = ls_bsak-blart.
    IF sy-subrc EQ 0.
      READ TABLE lt_j_1aotdetr INTO ls_j_1aotdetr
           WITH KEY doccls     = ls_t003_i-doccls
                    j_1aprtchr = ls_bsak-xblnr+4(1).
      IF sy-subrc EQ 0.
        ls_report_alv-tipo_comp = ls_j_1aotdetr-j_1aoftp.     "9
      ENDIF.
    ENDIF.

    READ TABLE lt_bkpf INTO ls_bkpf
         WITH KEY bukrs = ls_bsak-bukrs
                  belnr = ls_bsak-augbl
                  gjahr = ls_bsak-gjahr.
    IF sy-subrc EQ 0.
      ls_report_alv-brnch       = ls_bkpf-brnch.           "10
    ENDIF.

    READ TABLE lt_lfa1 INTO ls_lfa1
         WITH KEY lifnr = ls_bsak-lifnr.
    IF sy-subrc EQ 0.
      ls_report_alv-stcdt   = ls_lfa1-stcdt.              "6
      ls_report_alv-stcd1   = ls_lfa1-stcd1.              "7
      ls_report_alv-name1   = ls_lfa1-name1.              "18

      READ TABLE lt_adrc INTO ls_adrc
           WITH KEY addrnumber = ls_lfa1-adrnr.
      IF sy-subrc EQ 0.
        ls_report_alv-street     = ls_adrc-street.        "19
        ls_report_alv-house_num1 = ls_adrc-house_num1.    "20
        ls_report_alv-city1      = ls_adrc-city1.         "21
        ls_report_alv-post_code1 = ls_adrc-post_code1.    "24
        READ TABLE lt_t005u INTO ls_t005u
             WITH KEY bland = ls_adrc-region.
        IF sy-subrc EQ 0.
          ls_report_alv-bezei = ls_t005u-bezei.           "22
        ENDIF.
      ENDIF.
    ENDIF.

    READ TABLE lt_with_item INTO ls_with_item
         WITH KEY  bukrs = ls_bsak-bukrs
                   belnr = ls_bsak-augbl.
*Incidencia 1000054102 14.08.2018 DMARECA Ini
*                   gjahr = ls_bsak-gjahr.
*Incidencia 1000054102 14.08.2018 DMARECA Fin
    IF sy-subrc EQ 0 AND ls_with_item-ctnumber IS NOT INITIAL.
      ls_report_alv-budat    = ls_with_item-augdt.         "4
      ls_report_alv-ctnumber = ls_with_item-ctnumber.      "11
    ELSE.
      CONTINUE.
    ENDIF.

    READ TABLE lt_with_item2 INTO ls_with_item2
         WITH KEY bukrs = ls_bsak-bukrs
                  belnr = ls_bsak-belnr
                  gjahr = ls_bsak-gjahr.
    IF sy-subrc EQ 0.
      ls_report_alv-wt_qsshh  = ls_with_item2-wt_qsshh.    "13
      ls_report_alv-qsatz     = ls_with_item2-qsatz.       "14
      ls_report_alv-wt_qbshh  = ls_with_item2-wt_qbshh.    "15
    ENDIF.

    APPEND ls_report_alv TO lt_report_alv.
  ENDLOOP.

*  LOOP AT lt_bsak INTO ls_bsak.
*
*    CLEAR:ls_lfa1, ls_report_alv, ls_with_item.
*
*    ls_report_alv-belnr     = ls_bsak-belnr.              "1
*    ls_report_alv-wt_acco   = ls_bsak-lifnr.              "3
*    ls_report_alv-gjahr     = ls_bsak-gjahr.              "5
*    ls_report_alv-dmbtr     = ls_bsak-dmbtr.              "12
*    ls_report_alv-letra     = ls_bsak-xblnr+4(1).         "8
*
*    READ TABLE lt_t003_i INTO ls_t003_i
*         WITH KEY blart = ls_bsak-blart.
*    IF sy-subrc EQ 0.
*      READ TABLE lt_j_1aotdetr INTO ls_j_1aotdetr
*           WITH KEY doccls     = ls_t003_i-doccls
*                    j_1aprtchr = ls_bsak-xblnr+4(1).
*      IF sy-subrc EQ 0.
*        ls_report_alv-tipo_comp = ls_j_1aotdetr-j_1aoftp.     "9
*      ENDIF.
*    ENDIF.
*
*    READ TABLE lt_bkpf INTO ls_bkpf
*         WITH KEY bukrs = ls_bsak-bukrs
*                  belnr = ls_bsak-augbl
*                  gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-xblnr     = ls_bkpf-bktxt.              "2
*      ls_report_alv-brnch     = ls_bkpf-brnch.              "10
*    ENDIF.
*
*    READ TABLE lt_lfa1 INTO ls_lfa1
*         WITH KEY lifnr = ls_bsak-lifnr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-stcdt   = ls_lfa1-stcdt.              "6
*      ls_report_alv-stcd1   = ls_lfa1-stcd1.              "7
*      ls_report_alv-name1   = ls_lfa1-name1.              "18
*
*      READ TABLE lt_adrc INTO ls_adrc
*           WITH KEY addrnumber = ls_lfa1-adrnr.
*      IF sy-subrc EQ 0.
*        ls_report_alv-street     = ls_adrc-street.        "19
*        ls_report_alv-house_num1 = ls_adrc-house_num1.    "20
*        ls_report_alv-city1      = ls_adrc-city1.         "21
*        ls_report_alv-post_code1 = ls_adrc-post_code1.    "24
*        READ TABLE lt_t005u INTO ls_t005u
*             WITH KEY bland = ls_adrc-region.
*        IF sy-subrc EQ 0.
*          ls_report_alv-bezei = ls_t005u-bezei.           "22
*        ENDIF.
*      ENDIF.
*    ENDIF.
*
*    READ TABLE lt_with_item INTO ls_with_item
*         WITH KEY  bukrs = ls_bsak-bukrs
*                   belnr = ls_bsak-augbl
*                   gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0 AND ls_with_item-ctnumber IS NOT INITIAL.
*      ls_report_alv-budat    = ls_with_item-augdt.        "4
*      ls_report_alv-ctnumber = ls_with_item-ctnumber.     "11
*      ls_report_alv-wt_qsshh = ls_with_item-wt_qsshh.    "13
*      ls_report_alv-qsatz    = ls_with_item-qsatz.       "14
*      ls_report_alv-wt_qbshh = ls_with_item-wt_qbshh.    "15
*    ELSE.
*      CONTINUE.
*    ENDIF.
*
*    APPEND ls_report_alv TO lt_report_alv.
*  ENDLOOP.

ENDFORM.                    " GET_ALV
*&---------------------------------------------------------------------*
*&      Form  PRINT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print .
  DATA: ls_layout TYPE slis_layout_alv.

  ls_layout-colwidth_optimize = 'X'.

  PERFORM fieldcat_init USING lt_fieldcat[].

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_buffer_active    = 'X'
      i_callback_program = sy-repid
      is_layout          = ls_layout
      it_fieldcat        = lt_fieldcat[]
      i_save             = 'X'
    TABLES
      t_outtab           = lt_report_alv
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
ENDFORM.                    " PRINT
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_INIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_FIELDCAT[]  text
*----------------------------------------------------------------------*
FORM fieldcat_init  USING lt_fieldcat TYPE slis_t_fieldcat_alv.

  DATA: ls_fieldcat TYPE slis_fieldcat_alv.
  DATA: lv_linea TYPE i.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BELNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t01.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'XBLNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t02.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_ACCO'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t03.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BUDAT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t04.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'GJAHR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t05.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCDT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t06.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t07.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'LETRA'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t08.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'TIPO_COMP'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t09.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BRNCH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t10.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CTNUMBER'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t11.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'DMBTR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t12.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QSSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t13.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'QSATZ'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t14.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QBSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t15.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NAME1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t18.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STREET'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t19.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'HOUSE_NUM1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t20.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CITY1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t21.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BEZEI'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t22.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NO_USADO'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t23.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'POST_CODE1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t24.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

ENDFORM.                    " FIELDCAT_INIT
*&---------------------------------------------------------------------*
*&      Form  CLASE_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM clase_documentos .
  IF NOT lt_bsak[] IS INITIAL.
    SELECT land1 blart doccls
    FROM t003_i
    INTO TABLE lt_t003_i
    FOR ALL ENTRIES IN lt_bsak
    WHERE land1 = lc_ar AND
          blart = lt_bsak-blart.
    IF sy-subrc EQ 0.
      SELECT land1 id_report doccls j_1aprtchr j_1aoftp
      FROM j_1aotdetr
      INTO TABLE lt_j_1aotdetr
      FOR ALL ENTRIES IN lt_t003_i
      WHERE land1     = lc_ar            AND
            doccls    = lt_t003_i-doccls AND
            id_report = lc_j_1af217.
    ENDIF.
  ENDIF.
ENDFORM.                    " CLASE_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  DESCARGAR_FICHERO_DATOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM descargar_fichero_datos .

  DATA: lv_path           TYPE rlgrap-filename,
        lv_nombre_fichero TYPE string,
        lv_linea          TYPE string,
        lt_fichero        TYPE STANDARD TABLE OF string,
        lv_fecha(8)       TYPE c,
        lv_tipodoc(2)     TYPE n,
        lv_num_doc(11)    TYPE n,
        lv_tip_comp(2)    TYPE n,
        lv_letra(1)       TYPE c,
        lv_cod_emis(4)    TYPE n,
        lv_numero(8)      TYPE n,
        lv_base(15)       TYPE c,
        lv_alicuota(6)    TYPE c,
        lv_ali            TYPE ZMFI_ED_DEC5_2,
        lv_monto(15)      TYPE c,
        lv_count          TYPE i,
        lv_num            TYPE string.

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    EXPORTING
      program_name  = syst-repid
      dynpro_number = syst-dynnr
    CHANGING
      file_name     = lv_path
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  LOOP AT lt_report_alv INTO ls_report_alv.
    lv_fecha    = ls_report_alv-budat.
    lv_num_doc  = ls_report_alv-stcd1.
    lv_tipodoc  = ls_report_alv-stcdt.
    lv_tip_comp = ls_report_alv-tipo_comp+1(2).
    lv_letra    = ls_report_alv-letra.
    lv_cod_emis = ls_report_alv-brnch.
    lv_numero   = ls_report_alv-ctnumber.
    lv_base     = ls_report_alv-wt_qsshh.
    lv_alicuota = lv_ali = ls_report_alv-qsatz.
    lv_monto    = ls_report_alv-wt_qbshh.
    TRANSLATE: lv_letra   USING ' #'.

    CONDENSE lv_base.
    TRANSLATE lv_base USING '- '.
    lv_num = strlen( lv_base ).
    IF lv_num < 15.
      lv_count = 15 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_base INTO lv_base.
      ENDDO.
    ENDIF.

    CONDENSE lv_alicuota.
    lv_num = strlen( lv_alicuota ).
    IF lv_num < 6.
      lv_count = 6 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_alicuota INTO lv_alicuota.
      ENDDO.
    ENDIF.

    CONDENSE lv_monto.
    TRANSLATE lv_monto USING '- '.
    lv_num = strlen( lv_monto ).
    IF lv_num < 15.
      lv_count = 15 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_monto INTO lv_monto.
      ENDDO.
    ENDIF.

    CONCATENATE lv_fecha              "Fecha
                lv_tipodoc
                lv_num_doc
                lv_tip_comp
                lv_letra
                lv_cod_emis
                lv_numero
                lv_base
                lv_alicuota
                lv_monto
                INTO lv_linea.
    TRANSLATE lv_linea USING '# '.
    APPEND lv_linea TO lt_fichero.
    CLEAR: lv_linea,ls_report_alv.
  ENDLOOP.

  lv_nombre_fichero = lv_path.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename                = lv_nombre_fichero
      filetype                = 'ASC'
      append                  = ''
      write_field_separator   = ''
    TABLES
      data_tab                = lt_fichero
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      OTHERS                  = 22.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.                    " DESCARGAR_FICHERO_DATOS
*&---------------------------------------------------------------------*
*&      Form  DESCARGAR_FICHERO_RETPER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM descargar_fichero_retper .

  DATA: lv_path           TYPE rlgrap-filename,
        lv_nombre_fichero TYPE string,
        lv_linea          TYPE string,
        lt_fichero        TYPE STANDARD TABLE OF string,
        lv_tipodoc(2)     TYPE n,
        lv_num_doc(11)    TYPE n,
        lv_nombre(40)     TYPE c,
        lv_domicil(40)    TYPE c,
        lv_nro(5)         TYPE n,
        lv_localid(15)    TYPE c,
        lv_provinc(15)    TYPE c,
        lv_nousado(11)    TYPE n,
        lv_cod_pos(8)     TYPE c.

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    EXPORTING
      program_name  = syst-repid
      dynpro_number = syst-dynnr
    CHANGING
      file_name     = lv_path
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  LOOP AT lt_report_alv INTO ls_report_alv.
    lv_num_doc  = ls_report_alv-stcd1.
    lv_tipodoc  = ls_report_alv-stcdt.
    lv_nombre   = ls_report_alv-name1.
    lv_domicil  = ls_report_alv-street.
    lv_nro      = ls_report_alv-house_num1.
    lv_localid  = ls_report_alv-city1.
    lv_provinc  = ls_report_alv-bezei.
    lv_nousado  = '99999999999'.
    lv_cod_pos  = ls_report_alv-post_code1.

    SHIFT lv_nombre RIGHT DELETING TRAILING space.
    SHIFT lv_domicil RIGHT DELETING TRAILING space.
    SHIFT lv_localid RIGHT DELETING TRAILING space.
    TRANSLATE lv_cod_pos USING ' 0'.
    TRANSLATE: lv_nombre  USING ' #',
               lv_domicil USING ' #',
               lv_localid USING ' #',
               lv_provinc USING ' #',
               lv_cod_pos USING ' #'.

    CONCATENATE lv_tipodoc
                lv_num_doc
                lv_nombre
                lv_domicil
                lv_nro
                lv_localid
                lv_provinc
                lv_nousado
                lv_cod_pos
                INTO lv_linea.
    TRANSLATE lv_linea USING '# '.
    APPEND lv_linea TO lt_fichero.
    CLEAR: lv_linea,ls_report_alv.
  ENDLOOP.

  lv_nombre_fichero = lv_path.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename                = lv_nombre_fichero
      filetype                = 'ASC'
      append                  = ''
      write_field_separator   = ''
    TABLES
      data_tab                = lt_fichero
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      OTHERS                  = 22.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.                    " DESCARGAR_FICHERO_RETPER
*** INCLUDE ZMFI_RETENCIONES_TUCUMAN_F01
*** INCLUDE ZMFI_RETENCIONES_TUCUMAN_F01
