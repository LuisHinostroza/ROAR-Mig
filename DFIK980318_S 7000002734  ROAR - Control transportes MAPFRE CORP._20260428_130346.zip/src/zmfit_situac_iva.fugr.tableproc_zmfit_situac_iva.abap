*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMFIT_SITUAC_IVA
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMFIT_SITUAC_IVA    .

  PERFORM TABLEPROC.

ENDFUNCTION.
