*&---------------------------------------------------------------------*
*&      Form  VALIDATE_RETEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_reten .

  CONSTANTS: lc_land1 TYPE land1 VALUE 'AR',
             lc_witht TYPE witht VALUE 'RB'.

  DATA: lv_wt_withcd TYPE wt_withcd,
        lv_message TYPE string.

  IF s_witht-low <> lc_witht AND  s_witht-low IS NOT INITIAL.
    CONCATENATE 'El tipo de Retención debe ser' lc_witht INTO lv_message SEPARATED BY space.
    MESSAGE lv_message TYPE 'E' DISPLAY LIKE 'E'.
  ELSE.
    IF p_withcd IS NOT INITIAL.
      SELECT SINGLE wt_withcd
        FROM t059z
        INTO lv_wt_withcd
        WHERE land1     = lc_land1 AND
              witht     = lc_witht AND
              wt_withcd = p_withcd.
      IF sy-subrc <> 0.
        MESSAGE 'El indicador de Retención no es correcto' TYPE 'E' DISPLAY LIKE 'E'.
      ENDIF.

    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_RETEN
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  PERFORM cabecera_documentos.
  PERFORM documentos_compensados.
  PERFORM maestro_proveedores.
ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM cabecera_documentos .

  SELECT bukrs belnr gjahr budat brnch bktxt
  FROM bkpf
  INTO TABLE lt_bkpf
  WHERE bukrs EQ p_bukrs AND
        belnr IN s_belnr AND
        gjahr IN s_gjahr AND
        blart IN s_blart AND
        budat IN s_budat AND
        xstov NE lc_charx.
  IF sy-subrc EQ 0.
    IF NOT p_withcd IS INITIAL.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht      AND
            wt_withcd EQ p_withcd.
    ELSE.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs EQ lt_bkpf-bukrs AND
            belnr EQ lt_bkpf-belnr AND
            gjahr EQ lt_bkpf-gjahr AND
            witht IN s_witht.
    ENDIF.

  ENDIF.
ENDFORM.                    " CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM documentos_compensados .

  IF lt_with_item[] IS NOT INITIAL.
*    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
*    FROM bsak
*    INTO TABLE lt_bsak
*    FOR ALL ENTRIES IN lt_with_item
*    WHERE bukrs EQ p_bukrs            AND
*          augbl EQ lt_with_item-belnr AND
*          belnr NE lt_with_item-belnr AND
*          gjahr EQ lt_with_item-gjahr.
*    IF sy-subrc EQ 0.
*      IF NOT p_withcd IS INITIAL.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*        FROM with_item
*        INTO TABLE lt_with_item2
*        FOR ALL ENTRIES IN lt_bsak
*        WHERE bukrs     EQ p_bukrs AND
*              belnr     EQ lt_bsak-belnr AND
*              gjahr     EQ lt_bsak-gjahr AND
*              witht     IN s_witht       AND
*              wt_withcd EQ p_withcd.
*      ELSE.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*        FROM with_item
*        INTO TABLE lt_with_item2
*        FOR ALL ENTRIES IN lt_bsak
*        WHERE bukrs     EQ p_bukrs AND
*              belnr     EQ lt_bsak-belnr AND
*              gjahr     EQ lt_bsak-gjahr AND
*              witht     IN s_witht.
*      ENDIF.
*    ENDIF.
    "DMARECA 27.08.2018 1000054112 INI
*    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr shkzg
       "DMARECA 27.08.2018 1000054112 FIN
     FROM bsak
     INTO TABLE lt_bsak
     FOR ALL ENTRIES IN lt_with_item
     WHERE bukrs EQ p_bukrs            AND
           belnr EQ lt_with_item-belnr AND
           gjahr EQ lt_with_item-gjahr.

  ENDIF.

ENDFORM.                    " DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*&      Form  MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM maestro_proveedores .

  IF NOT lt_bsak[] IS INITIAL.
    SELECT lifnr name1 stcd1 stcd2 fityp stcdt
*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
           land1
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
      FROM lfa1
      INTO TABLE lt_lfa1
      FOR ALL ENTRIES IN lt_bsak
      WHERE lifnr EQ lt_bsak-lifnr AND
            land1 EQ lc_ar.
  ENDIF.

ENDFORM.                    " MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*&      Form  GET_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_alv .
*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
  DATA: lt_t059z TYPE TABLE OF t059z,
        ls_t059z TYPE t059z.

  SELECT *
    FROM t059z
    INTO TABLE lt_t059z
    WHERE qsatz IS NOT NULL."#EC CI_GENBUFF
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

*  LOOP AT lt_bsak INTO ls_bsak.
*
*    CLEAR:ls_lfa1, ls_report_alv,
*          ls_with_item, ls_with_item2.
*
*    ls_report_alv-belnr     = ls_bsak-belnr.              "1
*    ls_report_alv-xblnr     = ls_bsak-xblnr.              "2
*    ls_report_alv-wt_acco   = ls_bsak-lifnr.              "3
*    ls_report_alv-gjahr     = ls_bsak-gjahr.              "5
*    ls_report_alv-dmbtr     = ls_bsak-dmbtr.              "10
*
*    READ TABLE lt_lfa1 INTO ls_lfa1
*         WITH KEY lifnr = ls_bsak-lifnr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-name1   = ls_lfa1-name1.              "4
*      ls_report_alv-stcdt   = ls_lfa1-stcdt.              "6
*      ls_report_alv-stcd1   = ls_lfa1-stcd1.              "7
*    ENDIF.
*
*    READ TABLE lt_with_item INTO ls_with_item
*         WITH KEY  bukrs = ls_bsak-bukrs
*                   belnr = ls_bsak-augbl
*                   gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-budat    = ls_with_item-augdt.         "8
*      ls_report_alv-ctnumber = ls_with_item-ctnumber.      "9
*    ENDIF.
*
*    READ TABLE lt_with_item2 INTO ls_with_item2
*         WITH KEY bukrs = ls_bsak-bukrs
*                  belnr = ls_bsak-belnr
*                  gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-wt_qsshh  = ls_with_item2-wt_qsshh.    "11
*      ls_report_alv-wt_qbshh  = ls_with_item2-wt_qbshh.    "12
*      ls_report_alv-witht     = ls_with_item2-witht.       "13
*      ls_report_alv-wt_withcd = ls_with_item2-wt_withcd.   "14
*      ls_report_alv-qsatz     = ls_with_item2-qsatz.       "15
*    ENDIF.
*
*    ls_report_alv-xreversal   = lc_a.                       "16
*
*    READ TABLE lt_bkpf INTO ls_bkpf
*         WITH KEY bukrs = ls_bsak-bukrs
*                  belnr = ls_bsak-augbl
*                  gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-brnch       = ls_bkpf-brnch.           "17
*    ENDIF.
*
*    APPEND ls_report_alv TO lt_report_alv.
*  ENDLOOP.

  "DMARECA 27.08.2018 1000054112 INI
  LOOP AT lt_with_item INTO ls_with_item.
    CLEAR: ls_with_item-buzei.
    APPEND ls_with_item TO lt_with_itemaux.
  ENDLOOP.

  REFRESH: lt_with_item.
  LOOP AT lt_with_itemaux INTO ls_with_itemaux.
    COLLECT ls_with_itemaux INTO lt_with_item.
  ENDLOOP.

  LOOP AT lt_with_item INTO ls_with_item.
    MODIFY lt_with_item FROM ls_with_item.
  ENDLOOP.
  "DMARECA 27.08.2018 1000054112 FIN
  LOOP AT lt_bsak INTO ls_bsak.

    CLEAR:ls_lfa1, ls_report_alv, ls_with_item.

    ls_report_alv-belnr     = ls_bsak-belnr.              "1
    ls_report_alv-wt_acco   = ls_bsak-lifnr.              "3
    ls_report_alv-gjahr     = ls_bsak-gjahr.              "5
    "DMARECA 27.08.2018 1000054112 INI
*    ls_report_alv-dmbtr     = ls_bsak-dmbtr.              "10
    IF ls_bsak-shkzg = 'S'."suma
      ls_report_alv-dmbtr     = ls_bsak-dmbtr.              "10
    ELSE.
      ls_report_alv-dmbtr     = ls_bsak-dmbtr * -1.              "10
    ENDIF.

    "DMARECA 27.08.2018 1000054112 FIN
    READ TABLE lt_bkpf INTO ls_bkpf WITH KEY bukrs = ls_bsak-bukrs
                                             belnr = ls_bsak-belnr
                                             gjahr = ls_bsak-gjahr.
    IF sy-subrc = 0.
      ls_report_alv-xblnr = ls_bkpf-bktxt.              "2
      ls_report_alv-brnch = ls_bkpf-brnch.              "17
    ENDIF.

    READ TABLE lt_lfa1 INTO ls_lfa1
         WITH KEY lifnr = ls_bsak-lifnr.
    IF sy-subrc EQ 0.
      ls_report_alv-name1   = ls_lfa1-name1.              "4
      ls_report_alv-stcdt   = ls_lfa1-stcdt.              "6
      ls_report_alv-stcd1   = ls_lfa1-stcd1.              "7
    ENDIF.

    READ TABLE lt_with_item INTO ls_with_item
         WITH KEY  bukrs = ls_bsak-bukrs
                   belnr = ls_bsak-augbl.
* Ini LCa - Incidencia: 1000054112 - 14/08/2018
*                   gjahr = ls_bsak-gjahr.
* Fin LCa - Incidencia: 1000054112 - 14/08/2018
    IF sy-subrc EQ 0 AND ls_with_item-ctnumber IS NOT INITIAL.
      ls_report_alv-budat    = ls_with_item-augdt.         "8
      ls_report_alv-ctnumber = ls_with_item-ctnumber.      "9
      "DMARECA 27.08.2018 1000054112 INI
*        ls_report_alv-wt_qsshh  = ls_with_item-wt_qsshh.    "11
*        ls_report_alv-wt_qbshh  = ls_with_item-wt_qbshh.    "12
      "DMARECA 27.08.2018 1000054112 FIN
      ls_report_alv-witht     = ls_with_item-witht.       "13
      ls_report_alv-wt_withcd = ls_with_item-wt_withcd.   "14
      ls_report_alv-qsatz     = ls_with_item-qsatz.       "15

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
      IF ls_report_alv-qsatz IS INITIAL AND ls_report_alv-wt_withcd IS NOT INITIAL.
        READ TABLE lt_t059z
        WITH KEY land1 = ls_lfa1-land1
                 witht = ls_with_item-witht
                 wt_withcd = ls_with_item-wt_withcd
        INTO ls_t059z.

        IF sy-subrc IS INITIAL.
          ls_report_alv-qsatz = ls_t059z-qsatz.
          CLEAR: ls_t059z.
        ENDIF.
      ENDIF.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
    ELSE.
      CONTINUE.
    ENDIF.

    ls_report_alv-xreversal   = lc_a.                       "16
    "DMARECA 27.08.2018 1000054112 INI
    COLLECT ls_report_alv INTO lt_report_alv.


*    APPEND ls_report_alv TO lt_report_alv.
    "DMARECA 27.08.2018 1000054112 FIN
  ENDLOOP.

  "DMARECA 27.08.2018 1000054112 INI
  LOOP AT lt_report_alv INTO ls_report_alv.
    READ TABLE lt_with_item INTO ls_with_item
        WITH KEY  belnr = ls_report_alv-belnr
                  gjahr = ls_report_alv-gjahr.
    IF sy-subrc EQ 0.
      ls_report_alv-wt_qsshh  = ls_with_item-wt_qsshh.    "11
      ls_report_alv-wt_qbshh  = ls_with_item-wt_qbshh.
    ENDIF.

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
    PERFORM get_numero_comprobante CHANGING ls_report_alv.
    PERFORM get_numero_operacion CHANGING ls_report_alv.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

    MODIFY lt_report_alv FROM ls_report_alv.
  ENDLOOP.
  "DMARECA 27.08.2018 1000054112 FIN
ENDFORM.                    " GET_ALV
*&---------------------------------------------------------------------*
*&      Form  PRINT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print .
  DATA: ls_layout TYPE slis_layout_alv.

  ls_layout-colwidth_optimize = 'X'.

  PERFORM fieldcat_init USING lt_fieldcat[].

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_buffer_active    = 'X'
      i_callback_program = sy-repid
      is_layout          = ls_layout
      it_fieldcat        = lt_fieldcat[]
      i_save             = 'X'
    TABLES
      t_outtab           = lt_report_alv
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
ENDFORM.                    " PRINT
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_INIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_FIELDCAT[]  text
*----------------------------------------------------------------------*
FORM fieldcat_init  USING lt_fieldcat TYPE slis_t_fieldcat_alv.

  DATA: ls_fieldcat TYPE slis_fieldcat_alv.
  DATA: lv_linea TYPE i.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BELNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-004.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'XBLNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-005.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_ACCO'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-006.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NAME1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-007.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'GJAHR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-008.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCDT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-009.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-010.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BUDAT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-011.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CTNUMBER'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-012.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NUMERO_COMPROBANTE'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-024.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'DMBTR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-013.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QSSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-014.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QBSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-015.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'QSATZ'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-023.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WITHT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-016.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_WITHCD'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-017.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

*  CLEAR ls_fieldcat.
*  ADD 1 TO lv_linea.
*  ls_fieldcat-fieldname   = 'QSATZ'.
*  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
*  ls_fieldcat-seltext_m   = text-020.
*  ls_fieldcat-col_pos     = lv_linea.
*  APPEND ls_fieldcat TO lt_fieldcat.
*
  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'XREVERSAL'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-021.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BRNCH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-022.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NUMERO_OPERACION'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-025.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

ENDFORM.                    " FIELDCAT_INIT
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_file .

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
  CONSTANTS: lc_tipo_op_a TYPE c LENGTH 1 VALUE 'A',
             lc_comma TYPE C LENGTH 1 VALUE ',',
             lc_dot TYPE C LENGTH 1 VALUE '.',
             lc_slash TYPE C LENGTH 1 VALUE '/'.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

  DATA: lv_path               TYPE rlgrap-filename,
        lv_nombre_fichero     TYPE string,
        lv_linea              TYPE string,
        lt_fichero            TYPE STANDARD TABLE OF string,lv_cuit(13)    TYPE c,
        lv_fecha(10)   TYPE c,
*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
*Código antiguo:
*        lv_sucursal(4) TYPE n,
*        lv_emision(8)  TYPE n,
*Código nuevo:
        lv_sucursal    TYPE c LENGTH 5,
        lv_emision     TYPE c LENGTH 8,
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
        lv_impor(11)   TYPE c,
        lv_tipo_op(1)  TYPE c,
        lv_count       TYPE i,
        lv_num         TYPE string,
*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
        lv_cuit_aux          TYPE c LENGTH 11,
        lv_monto_imponible   TYPE c LENGTH 14,
        lv_alicuota          TYPE c LENGTH 5,
        lv_importe_retencion TYPE c LENGTH 13,
        lv_inicio_8_ultimos  TYPE i.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
*Código antiguo:
*  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
*    EXPORTING
*      program_name  = syst-repid
*      dynpro_number = syst-dynnr
*    CHANGING
*      file_name     = lv_path
*    EXCEPTIONS
*      mask_too_long = 1
*      OTHERS        = 2.
*  IF sy-subrc <> 0.
** Implement suitable error handling here
*  ENDIF.
*
*  LOOP AT lt_report_alv INTO ls_report_alv.
*    CONCATENATE ls_report_alv-budat+6(2) '/'
*                ls_report_alv-budat+4(2) '/'
*                ls_report_alv-budat+0(4) INTO lv_fecha.
*
*    lv_impor = ls_report_alv-wt_qbshh.
*    REPLACE '.' WITH ',' INTO lv_impor.
*    CONDENSE lv_impor.
*    lv_num = strlen( lv_impor ).
*    IF lv_num < 11.
*      lv_count = 11 - lv_num.
*      DO lv_count TIMES.
*        CONCATENATE '0' lv_impor INTO lv_impor.
*      ENDDO.
*    ENDIF.
*
*    CONCATENATE ls_report_alv-stcd1(2) ls_report_alv-stcd1+2(8) ls_report_alv-stcd1+10(1)
*    INTO lv_cuit SEPARATED BY '-'.
*    lv_sucursal = ls_report_alv-brnch.
*    lv_emision  = ls_report_alv-ctnumber.
*    lv_tipo_op  = ls_report_alv-xreversal.
*    TRANSLATE: lv_cuit    USING ' #',
*               lv_tipo_op USING ' #'.
*
*    CONCATENATE lv_cuit
*                lv_fecha
*                lv_sucursal
*                lv_emision
*                lv_impor
*                lv_tipo_op
*                INTO lv_linea.
*
*    TRANSLATE lv_linea USING '# '.
*    APPEND lv_linea TO lt_fichero.
*    CLEAR: lv_linea,ls_report_alv.
*  ENDLOOP.
*
*  lv_nombre_fichero = lv_path.
*
*  CALL FUNCTION 'GUI_DOWNLOAD'
*    EXPORTING
*      filename                = lv_nombre_fichero
*      filetype                = 'ASC'
*      append                  = ''
*      write_field_separator   = ''
*    TABLES
*      data_tab                = lt_fichero
*    EXCEPTIONS
*      file_write_error        = 1
*      no_batch                = 2
*      gui_refuse_filetransfer = 3
*      invalid_type            = 4
*      no_authority            = 5
*      unknown_error           = 6
*      header_not_allowed      = 7
*      separator_not_allowed   = 8
*      filesize_not_allowed    = 9
*      header_too_long         = 10
*      dp_error_create         = 11
*      dp_error_send           = 12
*      dp_error_write          = 13
*      unknown_dp_error        = 14
*      access_denied           = 15
*      dp_out_of_memory        = 16
*      disk_full               = 17
*      dp_timeout              = 18
*      file_not_found          = 19
*      dataprovider_exception  = 20
*      control_flush_error     = 21
*      OTHERS                  = 22.
*  IF sy-subrc <> 0.
** Implement suitable error handling here
*  ENDIF.
*Código nuevo:

  LOOP AT lt_report_alv INTO ls_report_alv.
    "CUIT
    lv_cuit_aux = ls_report_alv-stcd1.
    PERFORM add_zeros USING '' CHANGING lv_cuit_aux.

    CONCATENATE lv_cuit_aux(2) lv_cuit_aux+2(8) lv_cuit_aux+10(1)
    INTO lv_cuit SEPARATED BY '-'.

    "Fecha de retención
    WRITE ls_report_alv-budat DD/MM/YYYY TO lv_fecha.
    REPLACE ALL OCCURRENCES OF lc_dot IN lv_fecha WITH lc_slash.

    "Número de sucursal
    lv_sucursal = ls_report_alv-brnch.
    PERFORM add_zeros USING '' CHANGING lv_sucursal.

    "Número de emisión
    """"8 últimos dígitos del comprobante
    lv_inicio_8_ultimos = strlen( ls_report_alv-ctnumber ) - 8.

    IF lv_inicio_8_ultimos GE 0.
      lv_emision = ls_report_alv-ctnumber+lv_inicio_8_ultimos(8).
      PERFORM add_zeros USING '' CHANGING lv_emision.
    ELSE.
      lv_emision = ls_report_alv-ctnumber.
      PERFORM add_zeros USING '' CHANGING lv_emision.
    ENDIF.

    "Monto imponible
    lv_monto_imponible = round( val = ls_report_alv-wt_qsshh
                         dec = 2 ).

    PERFORM add_zeros USING lc_comma CHANGING lv_monto_imponible.

    "Alícuota
    lv_alicuota = round( val = ls_report_alv-qsatz
                                     dec = 2 ).
    PERFORM add_zeros USING lc_comma CHANGING lv_alicuota.

    "Importe de retencion
    lv_importe_retencion = round( val = ls_report_alv-wt_qbshh
                                  dec = 2 ).

    PERFORM add_zeros USING lc_comma CHANGING lv_importe_retencion.

    "Tipo de operación
    lv_tipo_op = lc_tipo_op_a.

    CONCATENATE lv_cuit
                lv_fecha
                lv_sucursal
                lv_emision
                lv_monto_imponible
                lv_alicuota
                lv_importe_retencion
                lv_tipo_op
                INTO lv_linea.

    TRANSLATE lv_linea USING '# '.
    APPEND lv_linea TO lt_fichero.
    CLEAR: lv_linea,ls_report_alv.

    CLEAR: lv_cuit,
           lv_cuit_aux,
           lv_fecha,
           lv_sucursal,
           lv_emision,
           lv_monto_imponible,
           lv_alicuota,
           lv_importe_retencion,
           lv_tipo_op.
  ENDLOOP.

  lv_nombre_fichero = gv_path.

  IF px_file IS NOT INITIAL.
    CALL FUNCTION 'GUI_DOWNLOAD'
      EXPORTING
        filename                 = lv_nombre_fichero
        filetype                 = 'ASC'
        append                   = ''
        write_field_separator    = ''
        write_lf_after_last_line = abap_false
      TABLES
        data_tab                 = lt_fichero
      EXCEPTIONS
        file_write_error         = 1
        no_batch                 = 2
        gui_refuse_filetransfer  = 3
        invalid_type             = 4
        no_authority             = 5
        unknown_error            = 6
        header_not_allowed       = 7
        separator_not_allowed    = 8
        filesize_not_allowed     = 9
        header_too_long          = 10
        dp_error_create          = 11
        dp_error_send            = 12
        dp_error_write           = 13
        unknown_dp_error         = 14
        access_denied            = 15
        dp_out_of_memory         = 16
        disk_full                = 17
        dp_timeout               = 18
        file_not_found           = 19
        dataprovider_exception   = 20
        control_flush_error      = 21
        OTHERS                   = 22.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDIF.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

ENDFORM.                    " DOWNLOAD_FILE

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_FILE_ALTAS_BAJAS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_file_altas_bajas.

  TYPES: BEGIN OF lty_altas_bajas,
           numero_operacion TYPE C length 20,
           cuit type C LENGTH 11,
           sucursal TYPE C LENGTH 5,
           fecha_operacion TYPE C LENGTH 10,
           alicuota TYPE C LENGTH 5,
           base_imponible TYPE C LENGTH 16,
           numero_comprobante TYPE C LENGTH 19,
         END OF lty_altas_bajas.

  CONSTANTS: lc_slash TYPE C LENGTH 1 VALUE '/',
             lc_dot   TYPE C LENGTH 1 VALUE '.',
             lc_sufijo_altas TYPE string VALUE '_altas',
             lc_sufijo_bajas TYPE string VALUE '_bajas'.

  DATA: lv_nombre_fichero_altas     TYPE string,
        lv_nombre_fichero_bajas     TYPE string,
        lv_linea_altas              TYPE string,
        lt_fichero_altas            TYPE STANDARD TABLE OF string,
        lv_linea_bajas              TYPE string,
        lt_fichero_bajas            TYPE STANDARD TABLE OF string,
        ls_altas_bajas              TYPE lty_altas_bajas,
        lt_altas_bajas              TYPE TABLE OF lty_altas_bajas.

  LOOP AT lt_report_alv INTO ls_report_alv.
    "Número de operación
    ls_altas_bajas-numero_operacion  = ls_report_alv-numero_operacion.

    "CUIT
    ls_altas_bajas-cuit = ls_report_alv-stcd1.
    PERFORM add_zeros USING '' CHANGING ls_altas_bajas-cuit.

    "Número de sucursal
    ls_altas_bajas-sucursal = ls_report_alv-brnch.
    PERFORM add_zeros USING '' CHANGING ls_altas_bajas-sucursal.

    "Fecha de operación
    WRITE ls_report_alv-budat DD/MM/YYYY TO ls_altas_bajas-fecha_operacion.
    REPLACE ALL OCCURRENCES OF lc_dot IN ls_altas_bajas-fecha_operacion WITH lc_slash.

    "Alícuota
    ls_altas_bajas-alicuota = round( val = ls_report_alv-qsatz
                                     dec = 2 ).
    PERFORM add_zeros USING '' CHANGING ls_altas_bajas-alicuota.

    "Base imponible
    ls_altas_bajas-base_imponible = round( val = ls_report_alv-wt_qsshh
                                    dec = 2 ).
    TRANSLATE ls_altas_bajas-base_imponible USING '- '. "se eliminan signos negativos
    PERFORM add_zeros USING '' CHANGING ls_altas_bajas-base_imponible.

    "Número de comprobante
    ls_altas_bajas-numero_comprobante = ls_report_alv-numero_comprobante.

    "Se añaden las líneas al fichero correspondiente
    """ALTAS
    CONCATENATE ls_altas_bajas-numero_operacion
                ls_altas_bajas-cuit
                ls_altas_bajas-sucursal
                ls_altas_bajas-fecha_operacion
                ls_altas_bajas-alicuota
                ls_altas_bajas-base_imponible
    INTO lv_linea_altas.

    TRANSLATE lv_linea_altas USING '# '.

    """BAJAS
    CONCATENATE ls_altas_bajas-cuit
                ls_altas_bajas-sucursal
                ls_altas_bajas-fecha_operacion
                ls_altas_bajas-alicuota
                ls_altas_bajas-base_imponible
                ls_altas_bajas-numero_comprobante
    INTO lv_linea_bajas.

    TRANSLATE lv_linea_bajas USING '# '.

    IF ls_report_alv-dmbtr GE 0.
      APPEND lv_linea_altas TO lt_fichero_altas.
    ELSE. "importe negativo
      APPEND lv_linea_bajas TO lt_fichero_bajas.
    ENDIF.

    CLEAR: ls_altas_bajas,
           lv_linea_altas,
           lv_linea_bajas.
  ENDLOOP.

*Nombres ficheros
  lv_nombre_fichero_altas = gv_path.
  lv_nombre_fichero_bajas = gv_path.

  IF NOT ( px_file IS INITIAL AND
           ( ( p_alt IS INITIAL AND p_baj IS NOT INITIAL ) OR
             ( p_alt IS NOT INITIAL AND p_baj IS INITIAL )
            )
          ). "añadimos los sufijos '_altas' o '_bajas' solo si se genera más de un fichero

    IF gv_path CS lc_dot.
      REPLACE ALL OCCURRENCES OF '.' IN lv_nombre_fichero_altas WITH lc_sufijo_altas && lc_dot.
      REPLACE ALL OCCURRENCES OF '.' IN lv_nombre_fichero_bajas WITH lc_sufijo_bajas && lc_dot.
    ELSE.
      CONCATENATE lv_nombre_fichero_altas lc_sufijo_altas INTO lv_nombre_fichero_altas.
      CONCATENATE lv_nombre_fichero_bajas lc_sufijo_bajas INTO lv_nombre_fichero_bajas.
    ENDIF.

  ENDIF.

*FICHERO ALTAS
  IF P_ALT IS NOT INITIAL.
    CALL FUNCTION 'GUI_DOWNLOAD'
      EXPORTING
        filename                 = lv_nombre_fichero_altas
        filetype                 = 'ASC'
        append                   = ''
        write_field_separator    = ''
        write_lf_after_last_line = abap_false
      TABLES
        data_tab                 = lt_fichero_altas
      EXCEPTIONS
        file_write_error         = 1
        no_batch                 = 2
        gui_refuse_filetransfer  = 3
        invalid_type             = 4
        no_authority             = 5
        unknown_error            = 6
        header_not_allowed       = 7
        separator_not_allowed    = 8
        filesize_not_allowed     = 9
        header_too_long          = 10
        dp_error_create          = 11
        dp_error_send            = 12
        dp_error_write           = 13
        unknown_dp_error         = 14
        access_denied            = 15
        dp_out_of_memory         = 16
        disk_full                = 17
        dp_timeout               = 18
        file_not_found           = 19
        dataprovider_exception   = 20
        control_flush_error      = 21
        OTHERS                   = 22.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDIF.

  IF p_baj IS NOT INITIAL.
*FICHERO ALTAS
    CALL FUNCTION 'GUI_DOWNLOAD'
      EXPORTING
        filename                 = lv_nombre_fichero_bajas
        filetype                 = 'ASC'
        append                   = ''
        write_field_separator    = ''
        write_lf_after_last_line = abap_false
      TABLES
        data_tab                 = lt_fichero_bajas
      EXCEPTIONS
        file_write_error         = 1
        no_batch                 = 2
        gui_refuse_filetransfer  = 3
        invalid_type             = 4
        no_authority             = 5
        unknown_error            = 6
        header_not_allowed       = 7
        separator_not_allowed    = 8
        filesize_not_allowed     = 9
        header_too_long          = 10
        dp_error_create          = 11
        dp_error_send            = 12
        dp_error_write           = 13
        unknown_dp_error         = 14
        access_denied            = 15
        dp_out_of_memory         = 16
        disk_full                = 17
        dp_timeout               = 18
        file_not_found           = 19
        dataprovider_exception   = 20
        control_flush_error      = 21
        OTHERS                   = 22.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.
  ENDIF.

ENDFORM.                    " DOWNLOAD_FILE_ALTAS_BAJAS

FORM add_zeros USING uv_separador TYPE c
                CHANGING cv_result TYPE c.
  DATA: lv_len TYPE i,
        lv_strlen TYPE i,
        lv_zeros_num TYPE i.

  SHIFT cv_result LEFT DELETING LEADING space.

  DESCRIBE FIELD cv_result LENGTH lv_len IN CHARACTER MODE. "longitud de la variable
  lv_strlen = strlen( cv_result ). "Caracteres informados

  lv_zeros_num = lv_len - lv_strlen.

  IF lv_zeros_num GE 0.
    cv_result = repeat( val = '0' occ = lv_zeros_num ) && cv_result.
  ENDIF.

  IF uv_separador IS NOT INITIAL.
    REPLACE ALL OCCURRENCES OF '.' IN cv_result WITH uv_separador.
  ENDIF.
ENDFORM.

FORM get_numero_comprobante CHANGING cs_alv_line TYPE ty_report_alv.

  CONSTANTS lc_slash TYPE c LENGTH 1 VALUE '/'.

  DATA: lv_sucursal TYPE c LENGTH 5,
        lv_8_ultimos TYPE c LENGTH 8,
        lv_inicio_8_ultimos TYPE i.

  """Sucursal
  lv_sucursal = ls_report_alv-brnch.
  PERFORM add_zeros USING '' CHANGING lv_sucursal.

  """"8 últimos dígitos del comprobante
  lv_inicio_8_ultimos = strlen( ls_report_alv-ctnumber ) - 8.

  IF lv_inicio_8_ultimos GE 0.
    lv_8_ultimos = ls_report_alv-ctnumber+lv_inicio_8_ultimos(8).
    PERFORM add_zeros USING '' CHANGING lv_8_ultimos.
  ELSE.
    lv_8_ultimos = ls_report_alv-ctnumber.
    PERFORM add_zeros USING '' CHANGING lv_8_ultimos.
  ENDIF.

  CONCATENATE ls_report_alv-budat(4)
              lv_sucursal
              lv_8_ultimos
  INTO ls_report_alv-numero_comprobante SEPARATED BY lc_slash.

  CLEAR: lv_sucursal,
         lv_8_ultimos,
         lv_inicio_8_ultimos.
ENDFORM.

FORM get_numero_operacion CHANGING cs_alv_line TYPE ty_report_alv.

  DATA: lv_brnch TYPE c LENGTH 5,
        lv_ctnumber TYPE c LENGTH 11.

  """Sucursal
  lv_brnch = ls_report_alv-brnch.
  PERFORM add_zeros USING '' CHANGING lv_brnch.

  """Número certificado
  lv_ctnumber = ls_report_alv-ctnumber.
  PERFORM add_zeros USING '' CHANGING lv_ctnumber.

  CONCATENATE ls_report_alv-gjahr
              lv_brnch
              lv_ctnumber
  INTO ls_report_alv-numero_operacion.

  CLEAR: lv_brnch,
         lv_ctnumber.
ENDFORM.

FORM get_path.
  DATA: lo_gui_frontend_services TYPE REF TO cl_gui_frontend_services,
        lt_filetable type filetable,
        lv_rc TYPE i.

  CREATE OBJECT lo_gui_frontend_services.

  CLEAR: gv_path.

  lo_gui_frontend_services->file_open_dialog(
    EXPORTING
      WINDOW_TITLE            = 'Seleccione la ruta para los archivos de altas/bajas. Se añadirán sufijos automáticamente.'
*      DEFAULT_EXTENSION       =     " Default Extension
*      DEFAULT_FILENAME        =     " Default File Name
*      FILE_FILTER             =     " File Extension Filter String
*      WITH_ENCODING           =     " File Encoding
*      INITIAL_DIRECTORY       =     " Initial Directory
*      MULTISELECTION          =     " Multiple selections poss.
    changing
      FILE_TABLE              =  lt_filetable   " Table Holding Selected Files
      RC                      =  lv_rc   " Return Code, Number of Files or -1 If Error Occurred
*      USER_ACTION             =     " User Action (See Class Constants ACTION_OK, ACTION_CANCEL)
*      FILE_ENCODING           =
    EXCEPTIONS
      FILE_OPEN_DIALOG_FAILED = 1
      CNTL_ERROR              = 2
      ERROR_NO_GUI            = 3
      NOT_SUPPORTED_BY_GUI    = 4
      OTHERS                  = 5
  ).

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.

    READ TABLE lt_filetable
    INDEX 1
    INTO gv_path.

    IF sy-subrc IS NOT INITIAL.
      MESSAGE TEXT-e01 TYPE 'E'.
    ENDIF.

  ENDIF.
ENDFORM.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
*** INCLUDE ZMFI_RETENCION_BUENOS_AIRES_F1
*** INCLUDE ZMFI_RETENCION_BUENOS_AIRES_F1
