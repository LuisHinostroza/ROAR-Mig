*&---------------------------------------------------------------------*
*& Include ZFI_RETENC_CAPITAL_FEDERAL_TOP                    Report ZFI_RETENC_CAPITAL_FEDERAL
*&
*&---------------------------------------------------------------------*

REPORT zfi_retenc_capital_federal.

*----------------------------------------------------------------------*
*                     T A B L A S   S A P	                             *
*----------------------------------------------------------------------*
TABLES: bkpf, bseg, with_item.

*----------------------------------------------------------------------*
*                           T I P O S	                                 *
*----------------------------------------------------------------------*
TYPES: BEGIN OF ty_bkpf,
        bukrs     TYPE bkpf-bukrs,
        belnr     TYPE bkpf-belnr,
        gjahr     TYPE bkpf-gjahr,
        budat     TYPE bkpf-budat,
        bktxt     TYPE bkpf-bktxt,
       END OF ty_bkpf,

       BEGIN OF ty_with_item,
        bukrs     TYPE with_item-bukrs,
        belnr     TYPE with_item-belnr,
        gjahr     TYPE with_item-gjahr,
        buzei     TYPE with_item-buzei,
        witht     TYPE with_item-witht,
        wt_withcd TYPE with_item-wt_withcd,
        augbl     TYPE with_item-augbl,
        augdt     TYPE with_item-augdt,
        ctnumber  TYPE with_item-ctnumber,
        wt_qsshh  TYPE with_item-wt_qsshh,
        wt_qbshh  TYPE with_item-wt_qbshh,
        qsatz     TYPE with_item-qsatz,
       END OF ty_with_item.

TYPES: BEGIN OF ty_bsak,
        bukrs TYPE bsak-bukrs,
        lifnr TYPE bsak-lifnr,
        augbl TYPE bsak-augbl,
        gjahr TYPE bsak-gjahr,
        belnr TYPE bsak-belnr,
        buzei TYPE bsak-buzei,
        xblnr TYPE bsak-xblnr,
        blart TYPE bsak-blart,
        dmbtr TYPE bsak-dmbtr,
END OF ty_bsak.

TYPES: BEGIN OF ty_with_item2,
        bukrs     TYPE with_item-bukrs,
        belnr     TYPE with_item-belnr,
        gjahr     TYPE with_item-gjahr,
        buzei     TYPE with_item-buzei,
        witht     TYPE with_item-witht,
        wt_withcd TYPE with_item-wt_withcd,
        wt_qsshh     TYPE with_item-wt_qsshh,
        wt_qbshh     TYPE with_item-wt_qbshh,
        qsatz     TYPE with_item-qsatz,
END OF ty_with_item2.

TYPES: BEGIN OF ty_lfa1,
        lifnr TYPE lfa1-lifnr,
        name1 TYPE lfa1-name1,
        regio TYPE lfa1-regio,
        adrnr TYPE lfa1-adrnr,
        stcd1 TYPE lfa1-stcd1,
        stcd2 TYPE lfa1-stcd2,
        fityp TYPE lfa1-fityp,
        stcdt TYPE lfa1-stcdt,
END OF ty_lfa1.

TYPES:BEGIN OF ty_adrc,
        addrnumber TYPE adrc-addrnumber,
        city1      TYPE adrc-city1,
        post_code1 TYPE adrc-post_code1,
        street     TYPE adrc-street,
        house_num1 TYPE adrc-house_num1,
END OF ty_adrc.

TYPES: BEGIN OF ty_report_alv,
        belnr          TYPE bsak-belnr,
        xblnr          TYPE bsak-xblnr,
        lifnr          TYPE with_item-wt_acco,
        augdt          TYPE with_item-augdt,
        gjahr          TYPE bsak-gjahr,
        stcdt          TYPE lfa1-stcdt,
        stcd1          TYPE lfa1-stcd1,
        ctnumber       TYPE with_item-ctnumber,
        dmbtr          TYPE bsak-dmbtr,
        wt_qsshh       TYPE with_item-wt_qsshh,
        qsatz          TYPE with_item-qsatz,
        wt_qbshh       TYPE with_item-wt_qbshh,
        witht          TYPE with_item-witht,
        wt_withcd      TYPE with_item-wt_withcd,
        name1          TYPE lfa1-name1,
        street         TYPE adrc-street,
        house_num1     TYPE adrc-house_num1,
        city1          TYPE adrc-city1,
        zprov          TYPE ZMFIT_PROV_CORDO-zprov,
        post_code1     TYPE adrc-post_code1,
        tipo           TYPE c, "Valor 1
        stcd2          TYPE lfa1-stcd2,
        sector(4)      TYPE c, "blanco
        torre(2)       TYPE c, "blanco
        departament(4) TYPE c, "blanco
        piso(3)        TYPE c, "blanco
        identificad(2) TYPE c, "Valor 01
        tip_ret(2)     TYPE c, "Valor 1
        concept_ret    TYPE ZMFIT_CONCEP_RET-zcodigo,
        cod_oper(8)    TYPE c, "Secuencial
  END OF ty_report_alv.


*----------------------------------------------------------------------*
*     T A B L A S   I N T E R N A S   y   E S T R U C T U R A S        *
*----------------------------------------------------------------------*
DATA: lt_bkpf         TYPE TABLE OF ty_bkpf,
      ls_bkpf         TYPE ty_bkpf,
      lt_with_item    TYPE TABLE OF ty_with_item,
      ls_with_item    TYPE ty_with_item,
      lt_bsak         TYPE TABLE OF ty_bsak,
      ls_bsak         TYPE ty_bsak,
      lt_with_item2   TYPE TABLE OF ty_with_item2,
      ls_with_item2   TYPE ty_with_item2,
      lt_concep_reten TYPE TABLE OF ZMFIT_CONCEP_RET,
      ls_concep_reten TYPE ZMFIT_CONCEP_RET,
      lt_lfa1         TYPE TABLE OF ty_lfa1,
      ls_lfa1         TYPE ty_lfa1,
      lt_adrc         TYPE TABLE OF ty_adrc,
      ls_adrc         TYPE ty_adrc,
      lt_prov_cordoba TYPE TABLE OF ZMFIT_PROV_CORDO,
      ls_prov_cordoba TYPE ZMFIT_PROV_CORDO,
      lt_report_alv   TYPE TABLE OF ty_report_alv,
      ls_report_alv   TYPE ty_report_alv,
      lt_fieldcat     TYPE slis_t_fieldcat_alv.

DATA: gt_catalogo TYPE lvc_t_fcat.

DATA: gs_layout   TYPE lvc_s_layo.

*----------------------------------------------------------------------*
*           V A R I A B L E S   Y   C O N S T A N T E S                *
*----------------------------------------------------------------------*
CONSTANTS:
      lc_charx VALUE 'X',
      lc_vst   TYPE bset-ktosl VALUE 'VST',
      lc_kr    TYPE bsak-blart VALUE 'KR',
      lc_re    TYPE bsak-blart VALUE 'RE'.
*** INCLUDE ZMFI_RETENCIONES_CORDOBA_TOP
*** INCLUDE ZMFI_RETENCIONES_CORDOBA_TOP
