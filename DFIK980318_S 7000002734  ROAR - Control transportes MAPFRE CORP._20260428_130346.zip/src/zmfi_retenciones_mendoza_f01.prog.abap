*&---------------------------------------------------------------------*
*&      Form  VALIDATE_RETEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_reten .

  CONSTANTS: lc_land1 TYPE land1 VALUE 'AR',
             lc_witht TYPE witht VALUE 'RM'.

  DATA: lv_wt_withcd TYPE wt_withcd,
        lv_message TYPE string.

  IF s_witht-low <> lc_witht AND  s_witht-low IS NOT INITIAL.
    CONCATENATE 'El tipo de Retención debe ser' lc_witht INTO lv_message SEPARATED BY space.
    MESSAGE lv_message TYPE 'E' DISPLAY LIKE 'E'.
  ELSE.
    IF p_withcd IS NOT INITIAL.
      SELECT SINGLE wt_withcd
        FROM t059z
        INTO lv_wt_withcd
        WHERE land1     = lc_land1 AND
              witht     = lc_witht AND
              wt_withcd = p_withcd.
      IF sy-subrc <> 0.
        MESSAGE 'El indicador de Retención no es correcto' TYPE 'E' DISPLAY LIKE 'E'.
      ENDIF.

    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_RETEN
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  PERFORM cabecera_documentos.
  PERFORM documentos_compensados.
  PERFORM maestro_proveedores.
ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM cabecera_documentos .

  SELECT bukrs belnr gjahr budat brnch bktxt
  FROM bkpf
  INTO TABLE lt_bkpf
  WHERE bukrs EQ p_bukrs AND
        belnr IN s_belnr AND
        gjahr IN s_gjahr AND
        blart IN s_blart AND
        budat IN s_budat AND
        xstov NE lc_charx.
  IF sy-subrc EQ 0.
    IF NOT p_withcd IS INITIAL.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht      AND
            wt_withcd EQ p_withcd.
    ELSE.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht.
    ENDIF.
  ENDIF.

ENDFORM.                    " CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM documentos_compensados .

  IF NOT lt_with_item[] IS INITIAL.
*    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
*    FROM bsak
*    INTO TABLE lt_bsak
*    FOR ALL ENTRIES IN lt_with_item
*    WHERE bukrs EQ p_bukrs            AND
*          augbl EQ lt_with_item-belnr AND
*          belnr NE lt_with_item-belnr AND
*          gjahr EQ lt_with_item-gjahr.
*    IF sy-subrc EQ 0.
*      IF NOT p_withcd IS INITIAL.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*        FROM with_item
*        INTO TABLE lt_with_item2
*        FOR ALL ENTRIES IN lt_bsak
*        WHERE bukrs     EQ p_bukrs AND
*              belnr     EQ lt_bsak-belnr AND
*              gjahr     EQ lt_bsak-gjahr AND
*              witht     IN s_witht       AND
*              wt_withcd EQ p_withcd.
*      ELSE.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*        FROM with_item
*        INTO TABLE lt_with_item2
*        FOR ALL ENTRIES IN lt_bsak
*        WHERE bukrs     EQ p_bukrs AND
*              belnr     EQ lt_bsak-belnr AND
*              gjahr     EQ lt_bsak-gjahr AND
*              witht     IN s_witht.
*      ENDIF.
*    ENDIF.
    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
      FROM bsak
      INTO TABLE lt_bsak
      FOR ALL ENTRIES IN lt_with_item
      WHERE bukrs EQ p_bukrs            AND
            belnr EQ lt_with_item-belnr AND
            gjahr EQ lt_with_item-gjahr.
  ENDIF.

ENDFORM.                    " DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*&      Form  MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM maestro_proveedores .
  IF NOT lt_bsak[] IS INITIAL.
    SELECT lifnr name1 stcd1 stcd2 fityp stcdt
    FROM lfa1
    INTO TABLE lt_lfa1
    FOR ALL ENTRIES IN lt_bsak
    WHERE lifnr EQ lt_bsak-lifnr AND
          land1 EQ lc_ar.
  ENDIF.
ENDFORM.                    " MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*&      Form  GET_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_alv .

*  LOOP AT lt_bsak INTO ls_bsak.
*
*    CLEAR:ls_lfa1, ls_report_alv,
*          ls_with_item, ls_with_item2.
*
*    ls_report_alv-belnr     = ls_bsak-belnr.              "1
*    ls_report_alv-xblnr     = ls_bsak-xblnr.              "15
*    ls_report_alv-wt_acco   = ls_bsak-lifnr.              "2
*    ls_report_alv-gjahr     = ls_bsak-gjahr.              "4
*    ls_report_alv-dmbtr     = ls_bsak-dmbtr.              "14
*
*    READ TABLE lt_lfa1 INTO ls_lfa1
*         WITH KEY lifnr = ls_bsak-lifnr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-name1   = ls_lfa1-name1.              "3
*      ls_report_alv-stcdt   = ls_lfa1-stcdt.              "5
*      ls_report_alv-stcd1   = ls_lfa1-stcd1.              "6
*    ENDIF.
*
*    READ TABLE lt_with_item INTO ls_with_item
*         WITH KEY  bukrs = ls_bsak-bukrs
*                   belnr = ls_bsak-augbl
*                   gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-budat    = ls_with_item-augdt.         "7
*      ls_report_alv-ctnumber = ls_with_item-ctnumber.      "8
*    ENDIF.
*
*    READ TABLE lt_with_item2 INTO ls_with_item2
*         WITH KEY bukrs = ls_bsak-bukrs
*                  belnr = ls_bsak-belnr
*                  gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-wt_qsshh  = ls_with_item2-wt_qsshh.    "09
*      ls_report_alv-wt_qbshh  = ls_with_item2-wt_qbshh.    "10
*      ls_report_alv-witht     = ls_with_item2-witht.       "11
*      ls_report_alv-wt_withcd = ls_with_item2-wt_withcd.   "12
*      ls_report_alv-qsatz     = ls_with_item2-qsatz.       "13
*    ENDIF.
*
*    APPEND ls_report_alv TO lt_report_alv.
*  ENDLOOP.

  LOOP AT lt_bsak INTO ls_bsak.

    CLEAR:ls_lfa1, ls_report_alv, ls_with_item.

    ls_report_alv-belnr     = ls_bsak-belnr.              "1
    ls_report_alv-wt_acco   = ls_bsak-lifnr.              "2
    ls_report_alv-gjahr     = ls_bsak-gjahr.              "4
    ls_report_alv-dmbtr     = ls_bsak-dmbtr.              "14


    READ TABLE lt_bkpf INTO ls_bkpf WITH KEY bukrs = ls_bsak-bukrs
                                             belnr = ls_bsak-belnr
                                             gjahr = ls_bsak-gjahr.
    IF sy-subrc = 0.
      ls_report_alv-xblnr = ls_bkpf-bktxt.                "15
    ENDIF.

    READ TABLE lt_lfa1 INTO ls_lfa1
         WITH KEY lifnr = ls_bsak-lifnr.
    IF sy-subrc EQ 0.
      ls_report_alv-name1   = ls_lfa1-name1.              "3
      ls_report_alv-stcdt   = ls_lfa1-stcdt.              "5
      ls_report_alv-stcd1   = ls_lfa1-stcd1.              "6
    ENDIF.

    READ TABLE lt_with_item INTO ls_with_item
         WITH KEY  bukrs = ls_bsak-bukrs
                   belnr = ls_bsak-augbl
                   gjahr = ls_bsak-gjahr.
    IF sy-subrc EQ 0 AND ls_with_item-ctnumber IS NOT INITIAL.
      ls_report_alv-budat    = ls_with_item-augdt.         "7
      ls_report_alv-ctnumber = ls_with_item-ctnumber.      "8
      ls_report_alv-wt_qsshh  = ls_with_item-wt_qsshh.    "09
      ls_report_alv-wt_qbshh  = ls_with_item-wt_qbshh.    "10
      ls_report_alv-witht     = ls_with_item-witht.       "11
      ls_report_alv-wt_withcd = ls_with_item-wt_withcd.   "12
      ls_report_alv-qsatz     = ls_with_item-qsatz.       "13
    ELSE.
      CONTINUE.
    ENDIF.

    APPEND ls_report_alv TO lt_report_alv.
  ENDLOOP.

ENDFORM.                    " GET_ALV
*&---------------------------------------------------------------------*
*&      Form  PRINT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print .
  DATA: ls_layout TYPE slis_layout_alv.

  ls_layout-colwidth_optimize = 'X'.

  PERFORM fieldcat_init USING lt_fieldcat[].

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_buffer_active    = 'X'
      i_callback_program = sy-repid
      is_layout          = ls_layout
      it_fieldcat        = lt_fieldcat[]
      i_save             = 'X'
    TABLES
      t_outtab           = lt_report_alv
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
ENDFORM.                    " PRINT
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_INIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_FIELDCAT[]  text
*----------------------------------------------------------------------*
FORM fieldcat_init  USING lt_fieldcat TYPE slis_t_fieldcat_alv.

  DATA: ls_fieldcat TYPE slis_fieldcat_alv.
  DATA: lv_linea TYPE i.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BELNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t01.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'XBLNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t15.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_ACCO'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t02.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NAME1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t03.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'GJAHR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t04.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCDT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t05.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t06.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BUDAT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t07.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CTNUMBER'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t08.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'DMBTR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t14.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QSSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t09.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QBSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t10.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WITHT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t11.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_WITHCD'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t12.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'QSATZ'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-t13.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.


ENDFORM.                    " FIELDCAT_INIT
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_file .

  DATA: lv_path               TYPE rlgrap-filename,
        lv_nombre_fichero     TYPE string,
        lv_linea              TYPE string,
        lt_fichero            TYPE STANDARD TABLE OF string,
        lv_cuit(13)           TYPE c,
        lv_denomin(80)        TYPE c,
        lv_comprobante(12)    TYPE n,
        lv_fecha(8)           TYPE c,
        lv_monto(15)          TYPE c,
        lv_alicuota_dec       TYPE ZMFI_ED_DEC5_2,
        lv_alicuota(5)        TYPE c,
        lv_monto_retenido(15) TYPE c.

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    EXPORTING
      program_name  = syst-repid
      dynpro_number = syst-dynnr
    CHANGING
      file_name     = lv_path
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  LOOP AT lt_report_alv INTO ls_report_alv.
    CONCATENATE ls_report_alv-stcd1(2) ls_report_alv-stcd1+2(8) ls_report_alv-stcd1+10(1)
    INTO lv_cuit SEPARATED BY '-'.
    lv_denomin     = ls_report_alv-name1.
    CONCATENATE '00' ls_report_alv-ctnumber INTO lv_comprobante.
    CONCATENATE ls_report_alv-budat+6(2)
                ls_report_alv-budat+4(2)
                ls_report_alv-budat+0(4) INTO lv_fecha.
    lv_monto          = ls_report_alv-wt_qsshh.
    lv_alicuota_dec   = ls_report_alv-qsatz.
    lv_alicuota = lv_alicuota_dec.
    CONDENSE lv_alicuota.
    SHIFT lv_alicuota RIGHT DELETING TRAILING space.
    lv_monto_retenido = ls_report_alv-wt_qbshh.

    CONDENSE: lv_monto, lv_monto_retenido.
    SHIFT lv_monto RIGHT DELETING TRAILING space.
    SHIFT lv_monto_retenido RIGHT DELETING TRAILING space.

    TRANSLATE: lv_denomin        USING ' #'.

    CONCATENATE lv_cuit
                lv_denomin
                lv_fecha
                lv_comprobante
                lv_fecha
                lv_monto
                lv_alicuota
                lv_monto_retenido
                INTO lv_linea.
    TRANSLATE lv_linea USING '# '.
    APPEND lv_linea TO lt_fichero.
    CLEAR: lv_comprobante,lv_linea,ls_report_alv,
           lv_monto, lv_alicuota, lv_monto_retenido.
  ENDLOOP.

  lv_nombre_fichero = lv_path.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename                = lv_nombre_fichero
      filetype                = 'ASC'
      append                  = ''
      write_field_separator   = ''
    TABLES
      data_tab                = lt_fichero
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      OTHERS                  = 22.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.                    " DOWNLOAD_FILE
*** INCLUDE ZMFI_RETENCIONES_MENDOZA_F01
*** INCLUDE ZMFI_RETENCIONES_MENDOZA_F01
