*&---------------------------------------------------------------------*
*&      Form  VALIDATE_RETEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_reten .

  CONSTANTS: lc_land1 TYPE land1 VALUE 'AR',
             lc_witht TYPE witht VALUE 'RA'.

  DATA: lv_wt_withcd TYPE wt_withcd,
        lv_message   TYPE string.

  IF s_witht-low <> lc_witht AND  s_witht-low IS NOT INITIAL.
    CONCATENATE 'El tipo de Retención debe ser' lc_witht INTO lv_message SEPARATED BY space.
    MESSAGE lv_message TYPE 'E' DISPLAY LIKE 'E'.
  ELSE.
    IF p_withcd IS NOT INITIAL.
      SELECT SINGLE wt_withcd
        FROM t059z
        INTO lv_wt_withcd
        WHERE land1     = lc_land1 AND
              witht     = lc_witht AND
              wt_withcd = p_withcd.
      IF sy-subrc <> 0.
        MESSAGE 'El indicador de Retención no es correcto' TYPE 'E' DISPLAY LIKE 'E'.
      ENDIF.

    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_RETEN
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  PERFORM cabecera_documentos.
  PERFORM documentos_compensados.
  PERFORM impuestos_documentos.
  PERFORM maestro_proveedores.
ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM cabecera_documentos .

  SELECT bukrs belnr gjahr budat bktxt
  FROM bkpf
  INTO TABLE lt_bkpf
  WHERE bukrs EQ p_bukrs AND
        belnr IN s_belnr AND
        gjahr IN s_gjahr AND
        blart IN s_blart AND
        budat IN s_budat AND
        xstov NE lc_charx.
  IF sy-subrc EQ 0.
    IF NOT p_withcd IS INITIAL.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht      AND
            wt_withcd EQ p_withcd.
    ELSE.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht.
    ENDIF.
  ENDIF.

ENDFORM.                    " CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM documentos_compensados .

  IF NOT lt_with_item[] IS INITIAL.
    SELECT bukrs lifnr augbl gjahr belnr buzei budat xblnr blart dmbtr
    FROM bsak
    INTO TABLE lt_bsak
    FOR ALL ENTRIES IN lt_with_item
    WHERE bukrs EQ p_bukrs            AND
          augbl EQ lt_with_item-belnr AND
          belnr NE lt_with_item-belnr AND
          augdt EQ lt_with_item-augdt.
    IF sy-subrc EQ 0.
      IF NOT p_withcd IS INITIAL.
        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
        FROM with_item
        INTO TABLE lt_with_item2
        FOR ALL ENTRIES IN lt_bsak
        WHERE bukrs     EQ p_bukrs AND
              belnr     EQ lt_bsak-belnr AND
              gjahr     EQ lt_bsak-gjahr AND
              witht     IN s_witht       AND
              wt_withcd EQ p_withcd.
      ELSE.
        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
        FROM with_item
        INTO TABLE lt_with_item2
        FOR ALL ENTRIES IN lt_bsak
        WHERE bukrs     EQ p_bukrs AND
              belnr     EQ lt_bsak-belnr AND
              gjahr     EQ lt_bsak-gjahr AND
              witht     IN s_witht.

      ENDIF.
    ENDIF.
*    SELECT bukrs lifnr augbl gjahr belnr buzei budat xblnr blart dmbtr
*      FROM bsak
*      INTO TABLE lt_bsak
*      FOR ALL ENTRIES IN lt_with_item
*      WHERE bukrs EQ p_bukrs            AND
*            belnr EQ lt_with_item-belnr AND
*            gjahr EQ lt_with_item-gjahr.

    SELECT *
    FROM zmfit_codigo_nor
    INTO TABLE lt_codigo_norma
    FOR ALL ENTRIES IN lt_with_item
    WHERE witht     EQ lt_with_item-witht AND
          wt_withcd EQ lt_with_item-wt_withcd.
  ENDIF.

ENDFORM.                    " DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*&      Form  IMPUESTOS_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM impuestos_documentos .

  IF NOT lt_bsak[] IS INITIAL.
    SELECT bukrs belnr gjahr buzei hwste ktosl
    FROM bset
    INTO TABLE lt_bset
    FOR ALL ENTRIES IN lt_bsak
    WHERE bukrs EQ p_bukrs       AND
          belnr EQ lt_bsak-belnr AND
          gjahr EQ lt_bsak-gjahr.
  ENDIF.

ENDFORM.                    " IMPUESTOS_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM maestro_proveedores .
  IF NOT lt_bsak[] IS INITIAL.
    SELECT lifnr name1 stcd1 stcd2 fityp stcdt
    FROM lfa1
    INTO TABLE lt_lfa1
    FOR ALL ENTRIES IN lt_bsak
    WHERE lifnr EQ lt_bsak-lifnr AND
          land1 EQ 'AR'.
    IF sy-subrc EQ 0.
      SELECT *
      FROM zmfit_situac_iva
      INTO TABLE lt_situac_iva
      FOR ALL ENTRIES IN lt_lfa1
      WHERE fityp EQ lt_lfa1-fityp.
      IF sy-subrc EQ 0.ENDIF.
    ENDIF.
    SELECT bukrs lifnr gridt
    FROM lfb1
    INTO TABLE lt_lfb1
    FOR ALL ENTRIES IN lt_bsak
    WHERE bukrs EQ p_bukrs AND
          lifnr EQ lt_bsak-lifnr.
    IF sy-subrc EQ 0.
      SELECT *
      FROM zmfit_situa_iibb
      INTO TABLE lt_situac_iibb
      FOR ALL ENTRIES IN lt_lfb1
      WHERE gridt EQ lt_lfb1-gridt.
    ENDIF.
  ENDIF.
ENDFORM.                    " MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*&      Form  GET_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_alv .

  LOOP AT lt_bsak INTO ls_bsak.
    CLEAR:ls_lfa1, ls_situac_iva,
          ls_with_item, ls_with_item2,
          ls_codigo_norma, ls_lfb1,
          ls_situac_iibb, ls_bset,
          ls_report_alv.

    ls_report_alv-belnr = ls_bsak-belnr.                "1-Documento
    ls_report_alv-lifnr = ls_bsak-lifnr.                "2-Acreedor
    ls_report_alv-gjahr = ls_bsak-gjahr.                "4-Ejercico

    READ TABLE lt_lfa1 INTO ls_lfa1 WITH KEY lifnr = ls_bsak-lifnr.
    IF sy-subrc EQ 0.
      ls_report_alv-name1 = ls_lfa1-name1.              "3-Nombre Acreedor
      ls_report_alv-stcdt = ls_lfa1-stcdt.              "5-NIF
      ls_report_alv-stcd1 = ls_lfa1-stcd1.              "6-CUIT
      ls_report_alv-stcd2 = ls_lfa1-stcd2.              "20-Nro.Inscripción de IIBB

      READ TABLE lt_situac_iva INTO ls_situac_iva
           WITH KEY fityp = ls_lfa1-fityp.
      IF sy-subrc EQ 0.
        ls_report_alv-zcodiva = ls_situac_iva-zcod.     "21-Situación de IVA
      ENDIF.
    ENDIF.

    READ TABLE lt_with_item INTO ls_with_item
         WITH KEY bukrs = ls_bsak-bukrs
                  belnr = ls_bsak-augbl.
* Ini 07/08/2018 - 1000054004
*                  gjahr = ls_bsak-gjahr.
* Fin 07/08/2018 - 1000054004
    IF sy-subrc EQ 0 AND ls_with_item-ctnumber IS NOT INITIAL.
      ls_report_alv-augdt    = ls_with_item-augdt.      "7-Fecha de Retención
      ls_report_alv-ctnumber = ls_with_item-ctnumber.   "8-Nº Certificado de Retención
    ELSE.
      CONTINUE.
    ENDIF.

    READ TABLE lt_with_item2 INTO ls_with_item2
         WITH KEY bukrs = ls_bsak-bukrs
                  belnr = ls_bsak-belnr
                  gjahr = ls_bsak-gjahr.
    IF sy-subrc EQ 0.
      ls_report_alv-wt_qsshh  = ls_with_item2-wt_qsshh. "9-Importe Sujeto Retención
      ls_report_alv-wt_qbshh  = ls_with_item2-wt_qbshh. "10-Importe Retenido
      ls_report_alv-witht     = ls_with_item2-witht.    "11-Tipo Retención
      ls_report_alv-wt_withcd = ls_with_item2-wt_withcd."12-Indicador Retención
      ls_report_alv-qsatz     = ls_with_item2-qsatz.    "13-Alícuota

      READ TABLE lt_codigo_norma INTO ls_codigo_norma
           WITH KEY witht     = ls_with_item2-witht
                    wt_withcd = ls_with_item2-wt_withcd.
      IF sy-subrc EQ 0.
        ls_report_alv-zcodnorma = ls_codigo_norma-zcod. "15-Código Norma
      ENDIF.
    ENDIF.

    ls_report_alv-tipo_operac = '1'.                    "14-Tipo Operación
    IF ls_bsak-blart EQ lc_kr OR ls_bsak-blart EQ lc_re.
      ls_report_alv-tip_comp = '01'.                    "16-Tipo Comprobante
    ENDIF.

    ls_report_alv-letra = ls_bsak-xblnr+4(1).           "17-Letra COmprobante
    ls_report_alv-dmbtr = ls_bsak-dmbtr.                "18-Monto
    READ TABLE lt_lfb1 INTO ls_lfb1
         WITH KEY bukrs = ls_bsak-bukrs
                  lifnr = ls_bsak-lifnr.
    IF sy-subrc EQ 0.
      READ TABLE lt_situac_iibb INTO ls_situac_iibb
           WITH KEY gridt = ls_lfb1-gridt.
      IF sy-subrc EQ 0.
        ls_report_alv-zcodiibb = ls_situac_iibb-zcod.   "19-Situación de IIBB
      ENDIF.
    ENDIF.
    IF ls_report_alv-zcodiibb = '4' OR ls_report_alv-zcodiibb IS INITIAL.
      ls_report_alv-zcodiibb = '4'.
    ENDIF.
*Inicio Modificacion 1000060647 03/06/2019 VGMEZVZ
*    ls_report_alv-stcd2 = '00000000000'.
    IF ls_report_alv-zcodiibb = '2' OR ls_report_alv-zcodiibb = '5'.
      ls_report_alv-stcd2 = ls_lfa1-stcd1.
    ELSE.
      ls_report_alv-stcd2 = '00000000000'.
    ENDIF.
*Fin Modificacion 1000060647 03/06/2019 VGMEZVZ

    LOOP AT lt_bset INTO ls_bset WHERE bukrs = ls_bsak-bukrs AND
                                       belnr = ls_bsak-belnr AND
                                       gjahr = ls_bsak-gjahr AND
                                       ktosl NE lc_vst.
      ls_report_alv-concepto = ls_report_alv-concepto + "22-Otros conceptos
                               ls_bset-hwste.
    ENDLOOP.

    READ TABLE lt_bset INTO ls_bset
         WITH KEY bukrs = ls_bsak-bukrs
                  belnr = ls_bsak-belnr
                  gjahr = ls_bsak-gjahr
                  ktosl = lc_vst.
    IF sy-subrc EQ 0.
      ls_report_alv-iva = ls_bset-hwste.                "23-IVA
    ENDIF.

    ls_report_alv-xblnr     = ls_bsak-xblnr.            "24-Nro. Factura
    ls_report_alv-imp_total = ls_bsak-dmbtr.            "25-Importe Total
*Inicio Modificacion 1000060647 03/06/2019 VGMEZVZ

    IF ls_report_alv-acepta = 'T'.
*      ls_report_alv-fe_ace = sy-datum.
    ENDIF.
*Fin Modificacion 1000060647 03/06/2019 VGMEZVZ
    APPEND ls_report_alv TO lt_report_alv.
  ENDLOOP.

*  LOOP AT lt_bsak INTO ls_bsak.
*    CLEAR:ls_lfa1, ls_situac_iva,
*          ls_with_item, ls_codigo_norma, ls_lfb1,
*          ls_situac_iibb, ls_bset,
*          ls_report_alv.
*
*    ls_report_alv-belnr = ls_bsak-belnr.                "1-Documento
*    ls_report_alv-lifnr = ls_bsak-lifnr.                "2-Acreedor
*    ls_report_alv-gjahr = ls_bsak-gjahr.                "4-Ejercico
*
*    READ TABLE lt_lfa1 INTO ls_lfa1 WITH KEY lifnr = ls_bsak-lifnr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-name1 = ls_lfa1-name1.              "3-Nombre Acreedor
*      ls_report_alv-stcdt = ls_lfa1-stcdt.              "5-NIF
*      ls_report_alv-stcd1 = ls_lfa1-stcd1.              "6-CUIT
*      ls_report_alv-stcd2 = ls_lfa1-stcd2.              "20-Nro.Inscripción de IIBB
*
*      READ TABLE lt_situac_iva INTO ls_situac_iva
*           WITH KEY fityp = ls_lfa1-fityp.
*      IF sy-subrc EQ 0.
*        ls_report_alv-zcodiva = ls_situac_iva-zcod.     "21-Situación de IVA
*      ENDIF.
*    ENDIF.
*
*    READ TABLE lt_with_item INTO ls_with_item
*         WITH KEY bukrs = ls_bsak-bukrs
*                  belnr = ls_bsak-augbl
*                  gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0 AND ls_with_item-ctnumber IS NOT INITIAL..
*      ls_report_alv-augdt    = ls_with_item-augdt.      "7-Fecha de Retención
*      ls_report_alv-ctnumber = ls_with_item-ctnumber.   "8-Nº Certificado de Retención
*      ls_report_alv-wt_qsshh  = ls_with_item-wt_qsshh. "9-Importe Sujeto Retención
*      ls_report_alv-wt_qbshh  = ls_with_item-wt_qbshh. "10-Importe Retenido
*      ls_report_alv-witht     = ls_with_item-witht.    "11-Tipo Retención
*      ls_report_alv-wt_withcd = ls_with_item-wt_withcd."12-Indicador Retención
*      ls_report_alv-qsatz     = ls_with_item-qsatz.    "13-Alícuota
*
*      READ TABLE lt_codigo_norma INTO ls_codigo_norma
*           WITH KEY witht     = ls_with_item-witht
*                    wt_withcd = ls_with_item-wt_withcd.
*      IF sy-subrc EQ 0.
*        ls_report_alv-zcodnorma = ls_codigo_norma-zcod. "15-Código Norma
*      ENDIF.
*    ELSE.
*      CONTINUE.
*    ENDIF.
*
*    ls_report_alv-tipo_operac = '1'.                    "14-Tipo Operación
*    IF ls_bsak-blart EQ lc_kr OR ls_bsak-blart EQ lc_re.
*      ls_report_alv-tip_comp = '01'.                    "16-Tipo Comprobante
*    ENDIF.
*
*    ls_report_alv-letra = ls_bsak-xblnr+4(1).           "17-Letra COmprobante
*    ls_report_alv-dmbtr = ls_bsak-dmbtr.                "18-Monto
*    READ TABLE lt_lfb1 INTO ls_lfb1
*         WITH KEY bukrs = ls_bsak-bukrs
*                  lifnr = ls_bsak-lifnr.
*    IF sy-subrc EQ 0.
*      READ TABLE lt_situac_iibb INTO ls_situac_iibb
*           WITH KEY gridt = ls_lfb1-gridt.
*      IF sy-subrc EQ 0.
*        ls_report_alv-zcodiibb = ls_situac_iibb-zcod.   "19-Situación de IIBB
*      ENDIF.
*    ENDIF.
*    IF ls_report_alv-zcodiibb = '4' OR ls_report_alv-zcodiibb IS INITIAL.
*      ls_report_alv-zcodiibb = '4'.
*      ls_report_alv-stcd2 = '00000000000'.
*    ENDIF.
*
*    LOOP AT lt_bset INTO ls_bset WHERE bukrs = ls_bsak-bukrs AND
*                                       belnr = ls_bsak-belnr AND
*                                       gjahr = ls_bsak-gjahr AND
*                                       ktosl NE lc_vst.
*      ls_report_alv-concepto = ls_report_alv-concepto + "22-Otros conceptos
*                               ls_bset-hwste.
*    ENDLOOP.
*
*    READ TABLE lt_bset INTO ls_bset
*         WITH KEY bukrs = ls_bsak-bukrs
*                  belnr = ls_bsak-belnr
*                  gjahr = ls_bsak-gjahr
*                  ktosl = lc_vst.
*    IF sy-subrc EQ 0.
*      ls_report_alv-iva = ls_bset-hwste.                "23-IVA
*    ENDIF.
*
*    READ TABLE lt_bkpf INTO ls_bkpf WITH KEY bukrs = ls_bsak-bukrs
*                                             belnr = ls_bsak-belnr
*                                             gjahr = ls_bsak-gjahr.
*    IF sy-subrc = 0.
*      ls_report_alv-xblnr = ls_bkpf-bktxt.              "24-Nro. Factura
*    ENDIF.
*    ls_report_alv-imp_total = ls_bsak-dmbtr.            "25-Importe Total
*    APPEND ls_report_alv TO lt_report_alv.
*  ENDLOOP.

ENDFORM.                    " GET_ALV
*&---------------------------------------------------------------------*
*&      Form  PRINT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print .
  DATA: ls_layout TYPE slis_layout_alv.

  ls_layout-colwidth_optimize = 'X'.

  PERFORM fieldcat_init USING lt_fieldcat[].

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_buffer_active    = 'X'
      i_callback_program = sy-repid
      is_layout          = ls_layout
      it_fieldcat        = lt_fieldcat[]
      i_save             = 'X'
    TABLES
      t_outtab           = lt_report_alv
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
ENDFORM.                    " PRINT
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_INIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_FIELDCAT[]  text
*----------------------------------------------------------------------*
FORM fieldcat_init  USING lt_fieldcat TYPE slis_t_fieldcat_alv.

  DATA: ls_fieldcat TYPE slis_fieldcat_alv.
  DATA: lv_linea TYPE i.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BELNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t01.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'XBLNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t24.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'LIFNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t02.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NAME1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t03.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'GJAHR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t04.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCDT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t05.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t06.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'AUGDT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t07.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CTNUMBER'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t08.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'IMP_TOTAL'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t25.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QSSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t09.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QBSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t10.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WITHT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t11.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_WITHCD'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t12.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

*  CLEAR ls_fieldcat.
*  ADD 1 TO lv_linea.
*  ls_fieldcat-fieldname   = 'QSATZ'.
*  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
*  ls_fieldcat-seltext_m   = text-t13.
*  ls_fieldcat-col_pos     = lv_linea.
*  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'TIPO_OPERAC'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t14.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'ZCODNORMA'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t15.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'TIP_COMP'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t16.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'LETRA'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t17.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'DMBTR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t18.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'ZCODIIBB'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t19.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD2'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t20.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'ZCODIVA'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t21.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CONCEPTO'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t22.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'IVA'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t23.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.


ENDFORM.                    " FIELDCAT_INIT
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_file .

  DATA: lv_path              TYPE rlgrap-filename,
        lv_nombre_fichero    TYPE string,
*Inicio modificacion 1000060647 03/06/2019 VGMEZVZ
*        lv_linea              TYPE string,
*        lt_fichero            TYPE STANDARD TABLE OF string,
        lv_linea(226)        TYPE c,
        lt_fichero           TYPE TABLE OF zmfi_ed_char226,
*Fin modificacion 1000060647 03/06/2019 VGMEZVZ
        lv_importe           TYPE zmfi_ed_dec5_2,
        lv_length            TYPE i,
        lv_string            TYPE string,
        lv_tipo_operacion    TYPE c,
        lv_codigo_norma(3)   TYPE c,
        lv_augdt(10)         TYPE c,
        lv_tipo_comprob(2)   TYPE c,
        lv_letra_comprob     TYPE c,
        lv_num_comprob(16)   TYPE c,
        lv_fecha_comprob(10) TYPE c,
        lv_monto_comprob(16) TYPE c,
        lv_num_certif(16)    TYPE c,
        lv_tipo_doc          TYPE c,
        lv_cuit(11)          TYPE c,
        lv_situacion_ib      TYPE c,
        lv_num_ib(11)        TYPE c,
        lv_situacion_iva     TYPE c,
        lv_razon_social(30)  TYPE c,
        lv_importe_otros(16) TYPE c,
        lv_importe_iva(16)   TYPE c,
        lv_monto_retenc(16)  TYPE c,
        lv_alicuota(5)       TYPE c,
        lv_importe_ret(16)   TYPE c,
        lv_monto_total(16)   TYPE c,
*Inicio modificacion 1000060647 03/06/2019 VGMEZVZ
        lv_aceptacion(1)     TYPE c,
        lv_fe_aceptacion(10) TYPE c.
*Fin modificacion 1000060647 03/06/2019 VGMEZVZ

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    EXPORTING
      program_name  = syst-repid
      dynpro_number = syst-dynnr
    CHANGING
      file_name     = lv_path
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  SORT lt_report_alv BY augdt.

  LOOP AT lt_report_alv INTO ls_report_alv.

    lv_tipo_operacion = ls_report_alv-tipo_operac.
    TRANSLATE lv_tipo_operacion USING ' *'.

    lv_codigo_norma = ls_report_alv-zcodnorma.
    TRANSLATE lv_codigo_norma USING ' *'.

    lv_augdt = ls_report_alv-augdt.
    CONCATENATE lv_augdt+6(2) '/' lv_augdt+4(2) '/' lv_augdt(4) INTO lv_augdt.

    lv_tipo_comprob = ls_report_alv-tip_comp.
    TRANSLATE lv_tipo_comprob USING ' *'.

    lv_letra_comprob = ls_report_alv-letra.
    TRANSLATE lv_letra_comprob USING ' *'.

    READ TABLE lt_bsak INTO ls_bsak WITH KEY bukrs = p_bukrs
                                             lifnr = ls_report_alv-lifnr
                                             gjahr = ls_report_alv-gjahr
                                             belnr = ls_report_alv-belnr.
    IF sy-subrc = 0.
      lv_num_comprob = ls_bsak-belnr.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = lv_num_comprob
        IMPORTING
          output = lv_num_comprob.

      CONCATENATE ls_bsak-budat+6(2) '/' ls_bsak-budat+4(2) '/' ls_bsak-budat(4)
      INTO lv_fecha_comprob.

      lv_monto_comprob = ls_report_alv-imp_total.
      TRANSLATE lv_monto_comprob USING '- '.
      CONDENSE lv_monto_comprob.
      lv_length = strlen( lv_monto_comprob ).
      IF lv_length < 16.
        lv_length = 16 - lv_length.
        SHIFT lv_monto_comprob RIGHT BY lv_length PLACES.
        TRANSLATE lv_monto_comprob USING ' 0'.
      ENDIF.
      TRANSLATE lv_monto_comprob USING '.,'.
    ENDIF.

    lv_num_certif = ls_report_alv-ctnumber.
    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = lv_num_certif
      IMPORTING
        output = lv_num_certif.
    IF lv_num_certif IS INITIAL.
      TRANSLATE lv_num_certif USING ' *'.
    ENDIF.

    lv_tipo_doc = '3'.
    TRANSLATE lv_tipo_doc USING ' *'.

    lv_cuit = ls_report_alv-stcd1.
    TRANSLATE lv_cuit USING ' *'.
*    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*      EXPORTING
*        input  = lv_cuit
*      IMPORTING
*        output = lv_cuit.

    lv_situacion_ib = ls_report_alv-zcodiibb.
    TRANSLATE lv_situacion_ib USING ' *'.

    lv_num_ib = ls_report_alv-stcd2.
    TRANSLATE lv_num_ib USING ' *'.

    lv_situacion_iva = ls_report_alv-zcodiva.
    TRANSLATE lv_situacion_iva USING ' *'.

    lv_razon_social = ls_report_alv-name1.
    TRANSLATE lv_razon_social USING ' *'.

    lv_importe_otros = ls_report_alv-concepto.
    TRANSLATE lv_importe_otros USING '- '.
    CONDENSE lv_importe_otros.
    lv_length = strlen( lv_importe_otros ).
    IF lv_length < 16.
      lv_length = 16 - lv_length.
      SHIFT lv_importe_otros RIGHT BY lv_length PLACES.
      TRANSLATE lv_importe_otros USING ' 0'.
    ENDIF.
    TRANSLATE lv_importe_otros USING '.,'.

    lv_importe_iva = ls_report_alv-iva.
    TRANSLATE lv_importe_iva USING '- '.
    CONDENSE lv_importe_iva.
    lv_length = strlen( lv_importe_iva ).
    IF lv_length < 16.
      lv_length = 16 - lv_length.
      SHIFT lv_importe_iva RIGHT BY lv_length PLACES.
      TRANSLATE lv_importe_iva USING ' 0'.
    ENDIF.
    TRANSLATE lv_importe_iva USING '.,'.

    lv_monto_retenc = ls_report_alv-wt_qsshh.
    TRANSLATE lv_monto_retenc USING '- '.
    CONDENSE lv_monto_retenc.
    lv_length = strlen( lv_monto_retenc ).
    IF lv_length < 16.
      lv_length = 16 - lv_length.
      SHIFT lv_monto_retenc RIGHT BY lv_length PLACES.
      TRANSLATE lv_monto_retenc USING ' 0'.
    ENDIF.
    TRANSLATE lv_monto_retenc USING '.,'.

    lv_importe = ls_report_alv-qsatz.
    lv_alicuota = lv_importe.
    CONDENSE lv_alicuota.
    lv_length = strlen( lv_alicuota ).
    IF lv_length < 5.
      lv_length = 5 - lv_length.
      SHIFT lv_alicuota RIGHT BY lv_length PLACES.
      TRANSLATE lv_alicuota USING ' 0'.
    ENDIF.
    TRANSLATE lv_alicuota USING '.,'.

    lv_importe_ret = ls_report_alv-wt_qbshh.
    TRANSLATE lv_importe_ret USING '- '.
    CONDENSE lv_importe_ret.
    lv_length = strlen( lv_importe_ret ).
    IF lv_length < 16.
      lv_length = 16 - lv_length.
      SHIFT lv_importe_ret RIGHT BY lv_length PLACES.
      TRANSLATE lv_importe_ret USING ' 0'.
    ENDIF.
    TRANSLATE lv_importe_ret USING '.,'.

    lv_monto_total(16) = lv_importe_ret.
*Inicio modificacion 1000060647 03/06/2019 VGMEZVZ
    IF ls_report_alv-acepta IS INITIAL.
      lv_aceptacion = ' '.
    ELSE.
      lv_aceptacion = ls_report_alv-acepta.
    ENDIF.
    IF ls_report_alv-fe_ace IS INITIAL.
      lv_fe_aceptacion = '          '.
    ELSE.
      CONCATENATE ls_report_alv-fe_ace(4) '/' ls_report_alv-fe_ace+4(2) '/' ls_report_alv-fe_ace+6(2) INTO lv_fe_aceptacion.
    ENDIF.
*Fin modificacion 1000060647 03/06/2019 VGMEZVZ

    CONCATENATE lv_tipo_operacion
                lv_codigo_norma
                lv_augdt
                lv_tipo_comprob
                lv_letra_comprob
                lv_num_comprob
                lv_fecha_comprob
                lv_monto_comprob
                lv_num_certif
                lv_tipo_doc
                lv_cuit
                lv_situacion_ib
                lv_num_ib
                lv_situacion_iva
                lv_razon_social
                lv_importe_otros
                lv_importe_iva
                lv_monto_retenc
                lv_alicuota
                lv_importe_ret
                lv_monto_total
*Inicio modificacion 1000060647 03/06/2019 VGMEZVZ
                lv_aceptacion
                lv_fe_aceptacion
*Fin modificacion 1000060647 03/06/2019 VGMEZVZ
    INTO lv_linea.
    TRANSLATE lv_linea USING '* '.
    APPEND lv_linea TO lt_fichero.
  ENDLOOP.

  lv_nombre_fichero = lv_path.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename                = lv_nombre_fichero
      filetype                = 'ASC'
      append                  = ''
      write_field_separator   = ''
    TABLES
      data_tab                = lt_fichero
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      OTHERS                  = 22.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.                    " DOWNLOAD_FILE
*** INCLUDE ZMFI_RETENC_CAPITAL_FEDERAL_F1
*** INCLUDE ZMFI_RETENC_CAPITAL_FEDERAL_F1
