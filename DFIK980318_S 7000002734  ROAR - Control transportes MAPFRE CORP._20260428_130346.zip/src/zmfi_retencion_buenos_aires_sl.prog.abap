*&---------------------------------------------------------------------*
*&  Include           ZFI_RETENCIONES_BUENOS_AIRES_SEL
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
*         P A N T A L L A    D E    S E L E C C I O N	                 *
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.

PARAMETERS:     p_bukrs TYPE bukrs                OBLIGATORY.
SELECT-OPTIONS: s_belnr FOR  bkpf-belnr,
                s_gjahr FOR  bkpf-gjahr           OBLIGATORY.
PARAMETERS:     p_rldnr TYPE fagl_rldnr           ."OBLIGATORY.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-001.

SELECT-OPTIONS: s_blart  FOR  bkpf-blart          OBLIGATORY,
                s_budat  FOR  bkpf-budat          OBLIGATORY,
                s_lifnr  FOR  bseg-lifnr,
                s_witht  FOR  with_item-witht     OBLIGATORY.
PARAMETERS:     p_withcd TYPE with_item-wt_withcd,
                px_file  AS CHECKBOX.

SELECTION-SCREEN END OF BLOCK b2.

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
SELECTION-SCREEN BEGIN OF BLOCK b3ba WITH FRAME TITLE text-003.
PARAMETERS: p_alt TYPE flag MODIF ID ba,
            p_baj TYPE flag MODIF ID ba.
SELECTION-SCREEN END OF BLOCK b3ba.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
*** INCLUDE ZMFI_RETENCION_BUENOS_AIRES_SL
*** INCLUDE ZMFI_RETENCION_BUENOS_AIRES_SL
