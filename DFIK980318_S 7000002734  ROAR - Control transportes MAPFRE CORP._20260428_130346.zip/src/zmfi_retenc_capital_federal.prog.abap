*&---------------------------------------------------------------------*
*& Report  ZFI_RETENC_CAPITAL_FEDERAL
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

INCLUDE ZMFI_RETENC_CAPITAL_FEDERAL_TP.
*INCLUDE zfi_retenc_capital_federal_top          .    " global Data
INCLUDE ZMFI_RETENC_CAPITAL_FEDERAL_SL.
*INCLUDE zfi_retenc_capital_federal_sel          .  " Pantalla de selección
INCLUDE ZMFI_RETENC_CAPITAL_FEDERAL_F1.
*INCLUDE zfi_retenc_capital_federal_f01          .  " FORM-Routines


*-------------------------------------------------------------- *
*           O B T E N C I Ó N   D E   D A T O S                 *
*-------------------------------------------------------------- *
START-OF-SELECTION.
  PERFORM validate_reten.
  PERFORM get_data.
  PERFORM get_alv.
  IF NOT lt_report_alv[] IS INITIAL.
    IF NOT px_file IS INITIAL.
      PERFORM download_file.
    ENDIF.
    PERFORM print.
  ENDIF.
