*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMFIT_TIPO_SIRCA................................*
DATA:  BEGIN OF STATUS_ZMFIT_TIPO_SIRCA              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMFIT_TIPO_SIRCA              .
CONTROLS: TCTRL_ZMFIT_TIPO_SIRCA
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMFIT_TIPO_SIRCA              .
TABLES: ZMFIT_TIPO_SIRCA               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
