FUNCTION-POOL ZMFIT87                    MESSAGE-ID SV.

* INCLUDE LZMFIT87D...                       " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMFIT87T00                             . "view rel. data dcl.
