*&---------------------------------------------------------------------*
*& Include ZFI_RETENCIONES_IIBB_TOP                          Report ZFI_RETENCIONES_IIBB
*&
*&---------------------------------------------------------------------*

REPORT zMfi_retenciones_iibb.

TABLES: bkpf,
        bseg,
        with_item.

CONSTANTS: gc_es        TYPE sy-langu       VALUE 'S',
           gc_ar        TYPE land1          VALUE 'AR'.

TYPES:BEGIN OF typ_t059u,
        witht     TYPE t059zt-witht,
        text40    TYPE t059zt-text40,
      END OF typ_t059u,


      BEGIN OF typ_t059zt,
        witht     TYPE t059zt-witht,
        wt_withcd TYPE t059zt-wt_withcd,
        text40    TYPE t059zt-text40,
      END OF typ_t059zt,

      BEGIN OF typ_match,
        shlpname  LIKE ddshretval-shlpname,
        fieldname LIKE ddshretval-fieldname,
        recordpos LIKE ddshretval-recordpos,
        fieldval  LIKE ddshretval-fieldval,
        retfield  LIKE ddshretval-retfield,
      END OF typ_match.

DATA:gt_t059zt     TYPE TABLE OF typ_t059zt,
     gs_t059zt     TYPE typ_t059zt,
     gt_match      TYPE TABLE OF typ_match,
     gs_match      TYPE typ_match.
*** INCLUDE ZMFI_RETENCIONES_IIBB_TOP
*** INCLUDE ZMFI_RETENCIONES_IIBB_TOP
