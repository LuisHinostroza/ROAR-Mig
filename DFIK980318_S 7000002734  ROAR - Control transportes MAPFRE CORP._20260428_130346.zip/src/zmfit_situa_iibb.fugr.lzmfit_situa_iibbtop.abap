FUNCTION-POOL ZMFIT_SITUA_IIBB           MESSAGE-ID SV.

* INCLUDE LZMFIT_SITUA_IIBBD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMFIT_SITUA_IIBBT00                    . "view rel. data dcl.
