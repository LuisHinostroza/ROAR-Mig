*&---------------------------------------------------------------------*
*& Include ZFI_RETENC_CAPITAL_FEDERAL_TOP                    Report ZFI_RETENC_CAPITAL_FEDERAL
*&
*&---------------------------------------------------------------------*

REPORT zfi_retenc_capital_federal.

*----------------------------------------------------------------------*
*                     T A B L A S   S A P	                             *
*----------------------------------------------------------------------*
TABLES: bkpf, bseg, with_item.

*----------------------------------------------------------------------*
*                           T I P O S	                                 *
*----------------------------------------------------------------------*
TYPES: BEGIN OF ty_bkpf,
        bukrs     TYPE bkpf-bukrs,
        belnr     TYPE bkpf-belnr,
        gjahr     TYPE bkpf-gjahr,
        budat     TYPE bkpf-budat,
        brnch     TYPE bkpf-brnch,
        bktxt     TYPE bkpf-bktxt,
       END OF ty_bkpf,

       BEGIN OF ty_with_item,
        bukrs     TYPE with_item-bukrs,
        belnr     TYPE with_item-belnr,
        gjahr     TYPE with_item-gjahr,
        buzei     TYPE with_item-buzei,
        witht     TYPE with_item-witht,
        wt_withcd TYPE with_item-wt_withcd,
        augbl     TYPE with_item-augbl,
        augdt     TYPE with_item-augdt,
        ctnumber  TYPE with_item-ctnumber,
        wt_qsshh  TYPE with_item-wt_qsshh,
        wt_qbshh  TYPE with_item-wt_qbshh,
        qsatz     TYPE with_item-qsatz,
       END OF ty_with_item.

TYPES: BEGIN OF ty_bsak,
        bukrs TYPE bsak-bukrs,
        lifnr TYPE bsak-lifnr,
        augbl TYPE bsak-augbl,
        gjahr TYPE bsak-gjahr,
        belnr TYPE bsak-belnr,
        buzei TYPE bsak-buzei,
        xblnr TYPE bsak-xblnr,
        blart TYPE bsak-blart,
        dmbtr TYPE bsak-dmbtr,
END OF ty_bsak.

TYPES: BEGIN OF ty_with_item2,
        bukrs     TYPE with_item-bukrs,
        belnr     TYPE with_item-belnr,
        gjahr     TYPE with_item-gjahr,
        buzei     TYPE with_item-buzei,
        witht     TYPE with_item-witht,
        wt_withcd TYPE with_item-wt_withcd,
        wt_qsshh  TYPE with_item-wt_qsshh,
        wt_qbshh  TYPE with_item-wt_qbshh,
        qsatz     TYPE with_item-qsatz,
END OF ty_with_item2.

TYPES: BEGIN OF ty_lfa1,
        lifnr TYPE lfa1-lifnr,
        name1 TYPE lfa1-name1,
        stcd1 TYPE lfa1-stcd1,
        stcd2 TYPE lfa1-stcd2,
        fityp TYPE lfa1-fityp,
        stcdt TYPE lfa1-stcdt,
END OF ty_lfa1.

TYPES: BEGIN OF ty_report_alv,
        belnr      TYPE bsak-belnr,
        xblnr      TYPE bsak-xblnr,
        wt_acco    TYPE with_item-wt_acco,
        name1      TYPE lfa1-name1,
        gjahr      TYPE bsak-gjahr,
        stcdt      TYPE lfa1-stcdt,
        stcd1      TYPE lfa1-stcd1,
        budat      TYPE bsak-budat,
        ctnumber   TYPE with_item-ctnumber,
        dmbtr      TYPE bsak-dmbtr,
        wt_qsshh   TYPE with_item-wt_qsshh,
        wt_qbshh   TYPE with_item-wt_qbshh,
        witht      TYPE with_item-witht,
        wt_withcd  TYPE with_item-wt_withcd,
        qsatz      TYPE with_item-qsatz,
  END OF ty_report_alv.


*----------------------------------------------------------------------*
*     T A B L A S   I N T E R N A S   y   E S T R U C T U R A S        *
*----------------------------------------------------------------------*
DATA: lt_bkpf         TYPE TABLE OF ty_bkpf,
      ls_bkpf         TYPE ty_bkpf,
      lt_with_item    TYPE TABLE OF ty_with_item,
      ls_with_item    TYPE ty_with_item,
      lt_bsak         TYPE TABLE OF ty_bsak,
      ls_bsak         TYPE ty_bsak,
      lt_with_item2   TYPE TABLE OF ty_with_item2,
      ls_with_item2   TYPE ty_with_item2,
      lt_lfa1         TYPE TABLE OF ty_lfa1,
      ls_lfa1         TYPE ty_lfa1,
      lt_report_alv   TYPE TABLE OF ty_report_alv,
      ls_report_alv   TYPE ty_report_alv,
      lt_fieldcat     TYPE slis_t_fieldcat_alv.

DATA: gt_catalogo TYPE lvc_t_fcat.

DATA: gs_layout   TYPE lvc_s_layo.

*----------------------------------------------------------------------*
*           V A R I A B L E S   Y   C O N S T A N T E S                *
*----------------------------------------------------------------------*
CONSTANTS:
      lc_charx VALUE 'X',
      lc_ar    TYPE t059z-land1 VALUE 'AR'.
*** INCLUDE ZMFI_RETENCIONES_MENDOZA_TOP
*** INCLUDE ZMFI_RETENCIONES_MENDOZA_TOP
