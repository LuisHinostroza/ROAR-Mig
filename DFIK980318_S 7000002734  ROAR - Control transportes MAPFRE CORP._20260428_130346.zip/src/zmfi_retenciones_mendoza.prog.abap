*&---------------------------------------------------------------------*
*& Report  ZFI_RETENC_CAPITAL_FEDERAL
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

INCLUDE ZMFI_RETENCIONES_MENDOZA_TOP.
*INCLUDE zfi_retenciones_mendoza_top.
INCLUDE ZMFI_RETENCIONES_MENDOZA_SEL.
*INCLUDE zfi_retenciones_mendoza_sel.
INCLUDE ZMFI_RETENCIONES_MENDOZA_F01.
*INCLUDE zfi_retenciones_mendoza_f01.

*-------------------------------------------------------------- *
*           O B T E N C I Ó N   D E   D A T O S                 *
*-------------------------------------------------------------- *
START-OF-SELECTION.
  PERFORM validate_reten.
  PERFORM get_data.
  PERFORM get_alv.
  IF NOT lt_report_alv[] IS INITIAL.
    IF NOT px_file IS INITIAL.
      PERFORM download_file.
    ENDIF.
    PERFORM print.
  ENDIF.
