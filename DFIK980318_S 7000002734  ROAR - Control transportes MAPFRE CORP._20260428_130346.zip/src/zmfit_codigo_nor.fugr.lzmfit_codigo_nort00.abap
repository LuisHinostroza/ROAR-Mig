*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMFIT_CODIGO_NOR................................*
DATA:  BEGIN OF STATUS_ZMFIT_CODIGO_NOR              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMFIT_CODIGO_NOR              .
CONTROLS: TCTRL_ZMFIT_CODIGO_NOR
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMFIT_CODIGO_NOR              .
TABLES: ZMFIT_CODIGO_NOR               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
