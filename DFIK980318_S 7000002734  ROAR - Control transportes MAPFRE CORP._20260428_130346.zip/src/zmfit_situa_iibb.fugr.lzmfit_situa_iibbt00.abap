*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMFIT_SITUA_IIBB................................*
DATA:  BEGIN OF STATUS_ZMFIT_SITUA_IIBB              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMFIT_SITUA_IIBB              .
CONTROLS: TCTRL_ZMFIT_SITUA_IIBB
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZMFIT_SITUA_IIBB              .
TABLES: ZMFIT_SITUA_IIBB               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
