*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMFIT_CODIGO_NORTOP.              " Global Declarations
  INCLUDE LZMFIT_CODIGO_NORUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMFIT_CODIGO_NORF...              " Subroutines
* INCLUDE LZMFIT_CODIGO_NORO...              " PBO-Modules
* INCLUDE LZMFIT_CODIGO_NORI...              " PAI-Modules
* INCLUDE LZMFIT_CODIGO_NORE...              " Events
* INCLUDE LZMFIT_CODIGO_NORP...              " Local class implement.
* INCLUDE LZMFIT_CODIGO_NORT99.              " ABAP Unit tests
  INCLUDE LZMFIT_CODIGO_NORF00                    . " subprograms
  INCLUDE LZMFIT_CODIGO_NORI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
