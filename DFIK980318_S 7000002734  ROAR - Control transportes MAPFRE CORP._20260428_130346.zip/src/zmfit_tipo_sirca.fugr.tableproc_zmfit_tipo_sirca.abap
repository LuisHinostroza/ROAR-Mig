*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMFIT_TIPO_SIRCA
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMFIT_TIPO_SIRCA    .

  PERFORM TABLEPROC.

ENDFUNCTION.
