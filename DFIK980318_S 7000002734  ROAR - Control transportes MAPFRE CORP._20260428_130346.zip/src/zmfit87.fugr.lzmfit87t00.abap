*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMFIT87.........................................*
DATA:  BEGIN OF STATUS_ZMFIT87                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMFIT87                       .
CONTROLS: TCTRL_ZMFIT87
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMFIT87                       .
TABLES: ZMFIT87                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
