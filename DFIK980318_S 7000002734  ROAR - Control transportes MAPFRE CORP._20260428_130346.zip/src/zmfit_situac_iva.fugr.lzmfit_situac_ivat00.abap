*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZMFIT_SITUAC_IVA................................*
DATA:  BEGIN OF STATUS_ZMFIT_SITUAC_IVA              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZMFIT_SITUAC_IVA              .
CONTROLS: TCTRL_ZMFIT_SITUAC_IVA
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZMFIT_SITUAC_IVA              .
TABLES: ZMFIT_SITUAC_IVA               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
