*&---------------------------------------------------------------------*
*&  Include           ZFI_RETENC_CAPITAL_FEDERAL_SEL
*&---------------------------------------------------------------------*

*----------------------------------------------------------------------*
*         P A N T A L L A    D E    S E L E C C I O N	                 *
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.

PARAMETERS:     p_bukrs TYPE bukrs                OBLIGATORY.
SELECT-OPTIONS: s_belnr FOR  bkpf-belnr,
                s_gjahr FOR  bkpf-gjahr           OBLIGATORY.
PARAMETERS:     p_rldnr TYPE fagl_rldnr           ."OBLIGATORY.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-001.

SELECT-OPTIONS: s_blart  FOR  bkpf-blart          OBLIGATORY,
                s_budat  FOR  bkpf-budat          OBLIGATORY,
                s_lifnr  FOR  bseg-lifnr,
                s_witht  FOR  with_item-witht     OBLIGATORY.
PARAMETERS:     p_withcd TYPE with_item-wt_withcd,
                px_file  AS CHECKBOX.

SELECTION-SCREEN END OF BLOCK b2.
*** INCLUDE ZMFI_RETENCIONES_CORDOBA_SEL
*** INCLUDE ZMFI_RETENCIONES_CORDOBA_SEL
