FUNCTION-POOL ZMFIT_SITUAC_IVA           MESSAGE-ID SV.

* INCLUDE LZMFIT_SITUAC_IVAD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMFIT_SITUAC_IVAT00                    . "view rel. data dcl.
