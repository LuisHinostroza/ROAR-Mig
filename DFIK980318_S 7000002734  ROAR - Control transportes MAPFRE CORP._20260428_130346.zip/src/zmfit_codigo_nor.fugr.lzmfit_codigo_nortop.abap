FUNCTION-POOL ZMFIT_CODIGO_NOR           MESSAGE-ID SV.

* INCLUDE LZMFIT_CODIGO_NORD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMFIT_CODIGO_NORT00                    . "view rel. data dcl.
