*----------------------------------------------------------------------*
*                 S U B R O U T I N E S   F O R M                      *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  VALIDATE_RETEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_reten .

  DATA: lt_zfi87 TYPE STANDARD TABLE OF zmfit87,
        lv_provincia TYPE zmfit87-provincia,
        lv_message TYPE string.

  IF rb_catam IS NOT INITIAL.
    lv_provincia = gc_catam.
  ELSEIF rb_chaco IS NOT INITIAL.
    lv_provincia = gc_chaco.
  ELSEIF rb_corri IS NOT INITIAL.
    lv_provincia = gc_corri.
  ELSEIF rb_jujuy IS NOT INITIAL.
    lv_provincia = gc_jujuy.
  ELSEIF rb_misio IS NOT INITIAL.
    lv_provincia = gc_misio.
  ELSEIF rb_pampa IS NOT INITIAL.
    lv_provincia = gc_pampa.
  ELSEIF rb_negro IS NOT INITIAL.
    lv_provincia = gc_negro.
  ELSEIF rb_sjuan IS NOT INITIAL.
    lv_provincia = gc_sjuan.
  ELSEIF rb_sluis IS NOT INITIAL.
    lv_provincia = gc_sluis.
  ELSEIF rb_salta IS NOT INITIAL.
    lv_provincia = gc_salta.
  ELSEIF rb_sanfe IS NOT INITIAL.
    lv_provincia = gc_sanfe.
  ELSEIF rb_santi IS NOT INITIAL.
    lv_provincia = gc_santi.
  ENDIF.

  IF p_withcd IS NOT INITIAL.

    SELECT *
      FROM zmfit87
      INTO TABLE lt_zfi87
      WHERE witht     IN s_witht  AND
            provincia EQ lv_provincia.
    IF sy-subrc <> 0.
      CONCATENATE text-024 text-026 INTO lv_message SEPARATED BY '.'.
      MESSAGE lv_message TYPE 'S' DISPLAY LIKE 'E'.
      gv_check_error = abap_true.
    ELSE.
      SELECT *
        FROM zmfit87
        INTO TABLE lt_zfi87
        WHERE witht     IN s_witht  AND
              wt_withcd EQ p_withcd AND
              provincia EQ lv_provincia.
      IF sy-subrc <> 0.
        CONCATENATE text-025 text-026 INTO lv_message SEPARATED BY '.'.
        MESSAGE lv_message TYPE 'S' DISPLAY LIKE 'E'.
        gv_check_error = abap_true.
      ENDIF.
    ENDIF.

  ELSE.

    SELECT *
      FROM zmfit87
      INTO TABLE lt_zfi87
      WHERE witht     IN s_witht  AND
            provincia EQ lv_provincia.
    IF sy-subrc <> 0.
      CONCATENATE text-024 text-026 INTO lv_message SEPARATED BY '.'.
      MESSAGE lv_message TYPE 'S' DISPLAY LIKE 'E'.
      gv_check_error = abap_true.
    ENDIF.

  ENDIF.

ENDFORM.                    " VALIDATE_RETEN
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .

  PERFORM cabecera_documentos.
  PERFORM documentos_compensados.
  PERFORM maestro_proveedores.
  PERFORM regimen_sircar.

ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM cabecera_documentos .

  SELECT bukrs belnr gjahr budat bktxt
    FROM bkpf
    INTO TABLE gt_bkpf
    WHERE bukrs EQ p_bukrs AND
          belnr IN s_belnr AND
          gjahr IN s_gjahr AND
          blart IN s_blart AND
          budat IN s_budat AND
          xstov NE gc_charx.
  IF sy-subrc EQ 0.
    IF p_withcd IS NOT INITIAL.

      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
        FROM with_item
        INTO TABLE gt_with_item
        FOR ALL ENTRIES IN gt_bkpf
        WHERE bukrs     EQ gt_bkpf-bukrs AND
              belnr     EQ gt_bkpf-belnr AND
              gjahr     EQ gt_bkpf-gjahr AND
              witht     IN s_witht      AND
              wt_withcd EQ p_withcd.

    ELSE.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
        FROM with_item
        INTO TABLE gt_with_item
        FOR ALL ENTRIES IN gt_bkpf
        WHERE bukrs EQ gt_bkpf-bukrs AND
              belnr EQ gt_bkpf-belnr AND
              gjahr EQ gt_bkpf-gjahr AND
              witht IN s_witht.
    ENDIF.
  ENDIF.

ENDFORM.                    " CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM documentos_compensados .

  IF gt_with_item[] IS NOT INITIAL.

*    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
*      FROM bsak
*      INTO TABLE gt_bsak
*      FOR ALL ENTRIES IN gt_with_item
*      WHERE bukrs EQ p_bukrs            AND
*            augbl EQ gt_with_item-belnr AND
*            belnr NE gt_with_item-belnr AND
*            gjahr EQ gt_with_item-gjahr.
*    IF sy-subrc EQ 0.
*
*      IF p_withcd IS NOT INITIAL.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*          FROM with_item
*          INTO TABLE gt_with_item2
*          FOR ALL ENTRIES IN gt_bsak
*          WHERE bukrs     EQ p_bukrs AND
*                belnr     EQ gt_bsak-belnr AND
*                gjahr     EQ gt_bsak-gjahr AND
*                witht     IN s_witht       AND
*                wt_withcd EQ p_withcd.
*      ELSE.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*          FROM with_item
*          INTO TABLE gt_with_item2
*          FOR ALL ENTRIES IN gt_bsak
*          WHERE bukrs EQ p_bukrs AND
*                belnr EQ gt_bsak-belnr AND
*                gjahr EQ gt_bsak-gjahr AND
*                witht IN s_witht.
*      ENDIF.
*      IF sy-subrc EQ 0.
*        SELECT witht wt_withcd qscod
*          FROM t059z
*          INTO TABLE gt_t059z
*          FOR ALL ENTRIES IN gt_with_item2
*          WHERE land1     = gc_ar               AND
*                witht     = gt_with_item2-witht AND
*                wt_withcd = gt_with_item2-wt_withcd.
*      ENDIF.
*    ENDIF.
    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
      FROM bsak
      INTO TABLE gt_bsak
      FOR ALL ENTRIES IN gt_with_item
      WHERE bukrs EQ p_bukrs            AND
            belnr EQ gt_with_item-belnr AND
            gjahr EQ gt_with_item-gjahr.

    SELECT witht wt_withcd qscod
      FROM t059z
      INTO TABLE gt_t059z
      FOR ALL ENTRIES IN gt_with_item
      WHERE land1     = gc_ar               AND
            witht     = gt_with_item-witht AND
            wt_withcd = gt_with_item-wt_withcd.

  ENDIF.

ENDFORM.                    " DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*&      Form  MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM maestro_proveedores .

  IF gt_bsak[] IS NOT INITIAL.
    SELECT lifnr name1 stcd1 stcd2 fityp stcdt
      FROM lfa1
      INTO TABLE gt_lfa1
      FOR ALL ENTRIES IN gt_bsak
      WHERE lifnr EQ gt_bsak-lifnr AND
            land1 EQ gc_ar.
  ENDIF.

ENDFORM.                    " MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*&      Form  GET_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_alv .

  DATA: lv_renglon(5) TYPE n.

*  LOOP AT gt_bsak INTO gs_bsak.
*
*    CLEAR:gs_lfa1, gs_sircar, gs_report_alv, gs_with_item, gs_with_item2, gs_t059z .
*
*    ADD 1 TO lv_renglon.
*    gs_report_alv-renglon   = lv_renglon.                 "1
*    gs_report_alv-belnr     = gs_bsak-belnr.              "2
*    gs_report_alv-xblnr     = gs_bsak-xblnr.              "3
*    gs_report_alv-wt_acco   = gs_bsak-lifnr.              "4
*    gs_report_alv-gjahr     = gs_bsak-gjahr.              "6
*    gs_report_alv-dmbtr     = gs_bsak-dmbtr.              "11
*
*    READ TABLE gt_lfa1 INTO gs_lfa1
*         WITH KEY lifnr = gs_bsak-lifnr.
*    IF sy-subrc EQ 0.
*      gs_report_alv-name1   = gs_lfa1-name1.              "5
*      gs_report_alv-stcdt   = gs_lfa1-stcdt.              "7
*      gs_report_alv-stcd1   = gs_lfa1-stcd1.              "8
*    ENDIF.
*
*    READ TABLE gt_with_item INTO gs_with_item
*         WITH KEY  bukrs = gs_bsak-bukrs
*                   belnr = gs_bsak-augbl
*                   gjahr = gs_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      gs_report_alv-budat    = gs_with_item-augdt.         "9
*      gs_report_alv-ctnumber = gs_with_item-ctnumber.      "10
*    ENDIF.
*
*    READ TABLE gt_with_item2 INTO gs_with_item2
*         WITH KEY bukrs = gs_bsak-bukrs
*                  belnr = gs_bsak-belnr
*                  gjahr = gs_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      gs_report_alv-wt_qsshh  = gs_with_item2-wt_qsshh.    "12
*      gs_report_alv-wt_qbshh  = gs_with_item2-wt_qbshh.    "13
*      gs_report_alv-witht     = gs_with_item2-witht.       "14
*      gs_report_alv-wt_withcd = gs_with_item2-wt_withcd.   "15
*      gs_report_alv-qsatz     = gs_with_item2-qsatz.       "18
*      READ TABLE gt_t059z INTO gs_t059z
*           WITH KEY witht     = gs_with_item2-witht
*                    wt_withcd = gs_with_item2-wt_withcd.
*      IF sy-subrc EQ 0.
*        gs_report_alv-qscod   = gs_t059z-qscod.            "19
*      ENDIF.
*    ENDIF.
*
*    gs_report_alv-origen_co = 1.                           "16
*    gs_report_alv-tipo_co = 1.                             "17
*
*    READ TABLE gt_sircar INTO gs_sircar
*         WITH KEY bukrs = p_bukrs
*                  witht = gs_report_alv-witht.
*    IF sy-subrc EQ 0.
*      gs_report_alv-jurisd    = gs_sircar-zcod.            "20
*    ENDIF.
*    APPEND gs_report_alv TO gt_report_alv.
*  ENDLOOP.

  LOOP AT gt_bsak INTO gs_bsak.

    CLEAR:gs_lfa1, gs_sircar, gs_report_alv, gs_with_item, gs_t059z .

    gs_report_alv-renglon   = lv_renglon.                 "1
    gs_report_alv-belnr     = gs_bsak-belnr.              "2
    gs_report_alv-wt_acco   = gs_bsak-lifnr.              "4
    gs_report_alv-gjahr     = gs_bsak-gjahr.              "6
    gs_report_alv-dmbtr     = gs_bsak-dmbtr.              "11

    READ TABLE gt_bkpf INTO gs_bkpf WITH KEY bukrs = gs_bsak-bukrs
                                             belnr = gs_bsak-belnr
                                             gjahr = gs_bsak-gjahr.

    IF sy-subrc = 0.
      gs_report_alv-xblnr = gs_bkpf-bktxt.              "3
    ENDIF.

    READ TABLE gt_lfa1 INTO gs_lfa1
         WITH KEY lifnr = gs_bsak-lifnr.
    IF sy-subrc EQ 0.
      gs_report_alv-name1   = gs_lfa1-name1.              "5
      gs_report_alv-stcdt   = gs_lfa1-stcdt.              "7
      gs_report_alv-stcd1   = gs_lfa1-stcd1.              "8
    ENDIF.

    READ TABLE gt_with_item INTO gs_with_item
         WITH KEY  bukrs = gs_bsak-bukrs
                   belnr = gs_bsak-belnr
                   gjahr = gs_bsak-gjahr.
    IF sy-subrc EQ 0 AND gs_with_item-ctnumber IS NOT INITIAL.
      gs_report_alv-budat    = gs_with_item-augdt.         "9
      gs_report_alv-ctnumber = gs_with_item-ctnumber.      "10
      gs_report_alv-wt_qsshh  = gs_with_item-wt_qsshh.    "12
      gs_report_alv-wt_qbshh  = gs_with_item-wt_qbshh.    "13
      gs_report_alv-witht     = gs_with_item-witht.       "14
      gs_report_alv-wt_withcd = gs_with_item-wt_withcd.   "15
      gs_report_alv-qsatz     = gs_with_item-qsatz.       "18

      READ TABLE gt_t059z INTO gs_t059z
           WITH KEY witht     = gs_with_item-witht
                    wt_withcd = gs_with_item-wt_withcd.
      IF sy-subrc EQ 0.
        gs_report_alv-qscod   = gs_t059z-qscod.            "19
      ENDIF.
    ELSE.
      CONTINUE.
    ENDIF.

    gs_report_alv-origen_co = 1.                           "16
    gs_report_alv-tipo_co = 1.                             "17

    READ TABLE gt_sircar INTO gs_sircar
         WITH KEY bukrs = p_bukrs
                  witht = gs_report_alv-witht.
    IF sy-subrc EQ 0.
      gs_report_alv-jurisd    = gs_sircar-zcod.            "20
    ENDIF.
    ADD 1 TO lv_renglon.
    APPEND gs_report_alv TO gt_report_alv.
  ENDLOOP.

ENDFORM.                    " GET_ALV
*&---------------------------------------------------------------------*
*&      Form  PRINT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print .

  DATA: ls_layout TYPE slis_layout_alv.

  ls_layout-colwidth_optimize = 'X'.

  PERFORM fieldcat_init USING gt_fieldcat[].

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_buffer_active    = 'X'
      i_callback_program = sy-repid
      is_layout          = ls_layout
      it_fieldcat        = gt_fieldcat[]
      i_save             = 'X'
    TABLES
      t_outtab           = gt_report_alv
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
ENDFORM.                    " PRINT
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_INIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_gt_FIELDCAT[]  text
*----------------------------------------------------------------------*
FORM fieldcat_init  USING gt_fieldcat TYPE slis_t_fieldcat_alv.

  DATA: ls_fieldcat TYPE slis_fieldcat_alv.
  DATA: lv_linea TYPE i.

*  CLEAR gs_fieldcat.
*  ADD 1 TO lv_linea.
*  gs_fieldcat-fieldname   = 'RENGLON'.
*  gs_fieldcat-tabname     = 'gt_REPORT_ALV'.
*  gs_fieldcat-seltext_m   = text-003.
*  gs_fieldcat-col_pos     = lv_linea.
*  APPEND gs_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BELNR'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-004.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'XBLNR'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-005.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_ACCO'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-006.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NAME1'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-007.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'GJAHR'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-008.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCDT'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-009.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD1'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-010.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BUDAT'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-011.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CTNUMBER'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-012.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'DMBTR'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-013.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QSSHH'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-014.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QBSHH'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-015.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WITHT'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-016.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_WITHCD'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-017.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'QSCOD'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-021.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'JURISD'.
  ls_fieldcat-tabname     = 'gt_REPORT_ALV'.
  ls_fieldcat-seltext_m   = text-022.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO gt_fieldcat.

ENDFORM.                    " FIELDCAT_INIT
*&---------------------------------------------------------------------*
*&      Form  REGIMEN_SIRCAR
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM regimen_sircar .

  SELECT *
    FROM zmfit_tipo_sirca
    INTO TABLE gt_sircar
    WHERE bukrs EQ p_bukrs AND
          witht IN s_witht.

ENDFORM.                    " REGIMEN_SIRCAR
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_file .

  DATA: lv_path               TYPE rlgrap-filename,
        lv_nombre_fichero     TYPE string,
        lv_linea              TYPE string,
        lt_fichero            TYPE STANDARD TABLE OF string,
        lv_comprobante(12)    TYPE c,
        lv_cuit(11)           TYPE c,
        lv_fecha(10)          TYPE c,
        lv_monto_sujeto(12)   TYPE c,
        lv_alicuota_dec       TYPE zmfi_ed_dec5_2,
        lv_alicuota(6)        TYPE c,
        lv_monto_retenido(12) TYPE c,
        lv_ali_conver         TYPE with_item-wt_qbshh." Se usa para la conversion a 2 decimales

*  IF rb_catam IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_catam '.txt' INTO lv_ruta.
*  ELSEIF rb_chaco IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_chaco '.txt' INTO lv_ruta.
*  ELSEIF rb_corri IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_corri '.txt' INTO lv_ruta.
*  ELSEIF rb_jujuy IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_jujuy '.txt' INTO lv_ruta.
*  ELSEIF rb_misio IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_misio '.txt' INTO lv_ruta.
*  ELSEIF rb_pampa IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_pampa '.txt' INTO lv_ruta.
*  ELSEIF rb_negro IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_negro '.txt' INTO lv_ruta.
*  ELSEIF rb_sjuan IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_sjuan '.txt' INTO lv_ruta.
*  ELSEIF rb_sluis IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_sluis '.txt' INTO lv_ruta.
*  ELSEIF rb_salta IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_salta '.txt' INTO lv_ruta.
*  ELSEIF rb_sanfe IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_sanfe '.txt' INTO lv_ruta.
*  ELSEIF rb_santi IS NOT INITIAL.
*    CONCATENATE '/tmp/' gc_santi '.txt' INTO lv_ruta.
*  ENDIF.

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    EXPORTING
      program_name  = syst-repid
      dynpro_number = syst-dynnr
    CHANGING
      file_name     = lv_path
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  LOOP AT gt_report_alv INTO gs_report_alv.
    CONCATENATE '00' gs_report_alv-ctnumber INTO lv_comprobante.
    CONCATENATE gs_report_alv-budat+6(2) '/'
                gs_report_alv-budat+4(2) '/'
                gs_report_alv-budat+0(4) INTO lv_fecha.
    lv_monto_sujeto = gs_report_alv-wt_qsshh.
    TRANSLATE lv_monto_sujeto USING '- '.
    SHIFT lv_monto_sujeto RIGHT DELETING TRAILING space.
    lv_alicuota_dec = gs_report_alv-qsatz.
    lv_alicuota = lv_alicuota_dec.
    SHIFT lv_alicuota RIGHT DELETING TRAILING space.
    lv_monto_retenido = gs_report_alv-wt_qbshh.
    TRANSLATE lv_monto_retenido USING '- '.
    SHIFT lv_monto_retenido RIGHT DELETING TRAILING space.
    lv_cuit = gs_report_alv-stcd1.
    SHIFT lv_cuit RIGHT DELETING TRAILING space.

    CONCATENATE gs_report_alv-renglon
                gs_report_alv-origen_co
                gs_report_alv-tipo_co
                lv_comprobante
                lv_cuit
                lv_fecha
                lv_monto_sujeto
                lv_alicuota
                lv_monto_retenido
                gs_report_alv-qscod
                gs_report_alv-jurisd
                INTO lv_linea SEPARATED BY ','.

    APPEND lv_linea TO lt_fichero.
    CLEAR: lv_comprobante,lv_linea,gs_report_alv,
           lv_monto_sujeto, lv_alicuota, lv_monto_retenido, lv_ali_conver.
  ENDLOOP.

  lv_nombre_fichero = lv_path.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename                = lv_nombre_fichero
      filetype                = 'ASC'
      append                  = ''
      write_field_separator   = ''
    TABLES
      data_tab                = lt_fichero
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      OTHERS                  = 22.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.                    " DOWNLOAD_FILE
*** INCLUDE ZMFI_RETENCIONES_SIRCAR_F01
*** INCLUDE ZMFI_RETENCIONES_SIRCAR_F01
