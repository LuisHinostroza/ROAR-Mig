*&---------------------------------------------------------------------*
*&  Include           ZFI_RETENCIONES_SIRCAR_SEL
*&---------------------------------------------------------------------*
*----------------------------------------------------------------------*
*                 S E L E C T I O N   S C R E E N	                     *
*----------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-000.

PARAMETERS:     p_bukrs TYPE bukrs                OBLIGATORY.
SELECT-OPTIONS: s_belnr FOR  bkpf-belnr,
                s_gjahr FOR  bkpf-gjahr           OBLIGATORY.
PARAMETERS:     p_rldnr TYPE fagl_rldnr           ."OBLIGATORY.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-001.

SELECT-OPTIONS: s_blart  FOR  bkpf-blart          OBLIGATORY,
                s_budat  FOR  bkpf-budat          OBLIGATORY,
                s_lifnr  FOR  bseg-lifnr,
                s_witht  FOR  with_item-witht     OBLIGATORY.
PARAMETERS:     p_withcd TYPE with_item-wt_withcd,
                px_file  AS CHECKBOX.

SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN BEGIN OF BLOCK b3 WITH FRAME TITLE text-001.

PARAMETERS: rb_catam RADIOBUTTON GROUP g1 USER-COMMAND f1,
            rb_chaco RADIOBUTTON GROUP g1,
            rb_corri RADIOBUTTON GROUP g1,
            rb_jujuy RADIOBUTTON GROUP g1,
            rb_misio RADIOBUTTON GROUP g1,
            rb_pampa RADIOBUTTON GROUP g1,
            rb_negro RADIOBUTTON GROUP g1,
            rb_sjuan RADIOBUTTON GROUP g1,
            rb_sluis RADIOBUTTON GROUP g1,
            rb_salta RADIOBUTTON GROUP g1,
            rb_sanfe RADIOBUTTON GROUP g1,
            rb_santi RADIOBUTTON GROUP g1.

SELECTION-SCREEN END OF BLOCK b3.
*** INCLUDE ZMFI_RETENCIONES_SIRCAR_SEL
*** INCLUDE ZMFI_RETENCIONES_SIRCAR_SEL
