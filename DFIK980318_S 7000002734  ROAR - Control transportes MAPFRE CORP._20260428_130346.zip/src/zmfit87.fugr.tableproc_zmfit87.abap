*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMFIT87
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMFIT87             .

  PERFORM TABLEPROC.

ENDFUNCTION.
