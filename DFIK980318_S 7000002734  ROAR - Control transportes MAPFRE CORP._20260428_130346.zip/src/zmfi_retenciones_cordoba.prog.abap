*&---------------------------------------------------------------------*
*& Report  ZFI_RETENC_CAPITAL_FEDERAL
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

INCLUDE ZMFI_RETENCIONES_CORDOBA_TOP.
*INCLUDE zfi_retenciones_cordoba_top.
INCLUDE ZMFI_RETENCIONES_CORDOBA_SEL.
*INCLUDE zfi_retenciones_cordoba_sel.
INCLUDE ZMFI_RETENCIONES_CORDOBA_F01.
*INCLUDE zfi_retenciones_cordoba_f01.

*-------------------------------------------------------------- *
*           O B T E N C I Ó N   D E   D A T O S                 *
*-------------------------------------------------------------- *
START-OF-SELECTION.
  PERFORM validate_reten.
  PERFORM get_data.
  PERFORM get_alv.
  IF NOT lt_report_alv[] IS INITIAL.
    IF NOT px_file IS INITIAL.
*      PERFORM subir_fichero_al11_proveedores.
*      PERFORM subir_fichero_al11_retenciones.
      PERFORM download_file.
    ENDIF.
    PERFORM print.
  ENDIF.
