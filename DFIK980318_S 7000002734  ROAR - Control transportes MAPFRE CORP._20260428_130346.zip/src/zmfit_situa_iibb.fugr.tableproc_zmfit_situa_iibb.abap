*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMFIT_SITUA_IIBB
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMFIT_SITUA_IIBB    .

  PERFORM TABLEPROC.

ENDFUNCTION.
