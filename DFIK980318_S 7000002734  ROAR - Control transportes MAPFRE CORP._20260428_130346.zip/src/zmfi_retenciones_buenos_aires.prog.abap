*&---------------------------------------------------------------------*
*& Report  ZFI_RETENCIONES_BUENOS_AIRES
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

INCLUDE ZMFI_RETENCION_BUENOS_AIRES_TP.
INCLUDE ZMFI_RETENCION_BUENOS_AIRES_SL.
INCLUDE ZMFI_RETENCION_BUENOS_AIRES_F1.

*-------------------------------------------------------------- *
*           O B T E N C I Ó N   D E   D A T O S                 *
*-------------------------------------------------------------- *
START-OF-SELECTION.
  PERFORM validate_reten.
  PERFORM get_data.
  PERFORM get_alv.
  IF NOT lt_report_alv[] IS INITIAL.

*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
*Código antiguo:
*    IF NOT px_file IS INITIAL.
*      PERFORM download_file.
*    ENDIF.
*Código nuevo:
    IF NOT ( px_file IS INITIAL AND p_alt IS INITIAL AND p_baj IS INITIAL ).
      PERFORM get_path.

      IF NOT px_file IS INITIAL.
        PERFORM download_file.
      ENDIF.

      IF NOT ( p_alt IS INITIAL AND p_baj IS INITIAL ).
        PERFORM download_file_altas_bajas.
      ENDIF.
    ENDIF.
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB

    PERFORM print.
  ENDIF.
