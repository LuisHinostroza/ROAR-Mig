*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZMFIT_CODIGO_NOR
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZMFIT_CODIGO_NOR    .

  PERFORM TABLEPROC.

ENDFUNCTION.
