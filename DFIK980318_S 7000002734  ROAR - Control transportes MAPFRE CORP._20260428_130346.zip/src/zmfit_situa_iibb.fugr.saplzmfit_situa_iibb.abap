*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMFIT_SITUA_IIBBTOP.              " Global Declarations
  INCLUDE LZMFIT_SITUA_IIBBUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMFIT_SITUA_IIBBF...              " Subroutines
* INCLUDE LZMFIT_SITUA_IIBBO...              " PBO-Modules
* INCLUDE LZMFIT_SITUA_IIBBI...              " PAI-Modules
* INCLUDE LZMFIT_SITUA_IIBBE...              " Events
* INCLUDE LZMFIT_SITUA_IIBBP...              " Local class implement.
* INCLUDE LZMFIT_SITUA_IIBBT99.              " ABAP Unit tests
  INCLUDE LZMFIT_SITUA_IIBBF00                    . " subprograms
  INCLUDE LZMFIT_SITUA_IIBBI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
