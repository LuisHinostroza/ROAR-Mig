*&---------------------------------------------------------------------*
*& Include ZFI_RETENCIONES_SIRCAR_TOP                    Report ZFI_RETENC_CAPITAL_FEDERAL
*&
*&---------------------------------------------------------------------*

REPORT zfi_retenciones_sircar.

*----------------------------------------------------------------------*
*                    S A P   T A B L E S                               *
*----------------------------------------------------------------------*
TABLES: bkpf, bseg, with_item.

*----------------------------------------------------------------------*
*                         T Y P E S                                    *
*----------------------------------------------------------------------*
TYPES:

  BEGIN OF ty_bkpf,
    bukrs TYPE bkpf-bukrs,
    belnr TYPE bkpf-belnr,
    gjahr TYPE bkpf-gjahr,
    budat TYPE bkpf-budat,
    bktxt TYPE bkpf-bktxt,
  END OF ty_bkpf,

  BEGIN OF ty_with_item,
    bukrs     TYPE with_item-bukrs,
    belnr     TYPE with_item-belnr,
    gjahr     TYPE with_item-gjahr,
    buzei     TYPE with_item-buzei,
    witht     TYPE with_item-witht,
    wt_withcd TYPE with_item-wt_withcd,
    augbl     TYPE with_item-augbl,
    augdt     TYPE with_item-augdt,
    ctnumber  TYPE with_item-ctnumber,
    wt_qsshh  TYPE with_item-wt_qsshh,
    wt_qbshh  TYPE with_item-wt_qbshh,
    qsatz     TYPE with_item-qsatz,
  END OF ty_with_item,

  BEGIN OF ty_bsak,
    bukrs TYPE bsak-bukrs,
    lifnr TYPE bsak-lifnr,
    augbl TYPE bsak-augbl,
    gjahr TYPE bsak-gjahr,
    belnr TYPE bsak-belnr,
    buzei TYPE bsak-buzei,
    xblnr TYPE bsak-xblnr,
    blart TYPE bsak-blart,
    dmbtr TYPE bsak-dmbtr,
  END OF ty_bsak,

  BEGIN OF ty_with_item2,
    bukrs     TYPE with_item-bukrs,
    belnr     TYPE with_item-belnr,
    gjahr     TYPE with_item-gjahr,
    buzei     TYPE with_item-buzei,
    witht     TYPE with_item-witht,
    wt_withcd TYPE with_item-wt_withcd,
    wt_qsshh  TYPE with_item-wt_qsshh,
    wt_qbshh  TYPE with_item-wt_qbshh,
    qsatz     TYPE with_item-qsatz,
  END OF ty_with_item2,

  BEGIN OF ty_t059z,
    witht     TYPE t059z-witht,
    wt_withcd TYPE t059z-wt_withcd,
    qscod     TYPE t059z-qscod,
  END OF ty_t059z,

  BEGIN OF ty_lfa1,
    lifnr TYPE lfa1-lifnr,
    name1 TYPE lfa1-name1,
    stcd1 TYPE lfa1-stcd1,
    stcd2 TYPE lfa1-stcd2,
    fityp TYPE lfa1-fityp,
    stcdt TYPE lfa1-stcdt,
  END OF ty_lfa1,

  BEGIN OF ty_report_alv,
    renglon(5) TYPE c,
    belnr      TYPE bsak-belnr,
    xblnr      TYPE bsak-xblnr,
    wt_acco    TYPE with_item-wt_acco,
    name1      TYPE lfa1-name1,
    gjahr      TYPE bsak-gjahr,
    stcdt      TYPE lfa1-stcdt,
    stcd1      TYPE lfa1-stcd1,
    budat      TYPE bsak-budat,
    ctnumber   TYPE with_item-ctnumber,
    dmbtr      TYPE bsak-dmbtr,
    wt_qsshh   TYPE with_item-wt_qsshh,
    wt_qbshh   TYPE with_item-wt_qbshh,
    witht      TYPE with_item-witht,
    wt_withcd  TYPE with_item-wt_withcd,
    origen_co  TYPE c,
    tipo_co    TYPE c,
    qsatz      TYPE with_item-qsatz,
    qscod      TYPE t059z-qscod,
    jurisd     TYPE zmfit_tipo_sirca-zcod,
  END OF ty_report_alv.

*----------------------------------------------------------------------*
*                I N T E R N A L   T A B L E S                         *
*----------------------------------------------------------------------*
DATA: gt_bkpf       TYPE TABLE OF ty_bkpf,
      gt_with_item  TYPE TABLE OF ty_with_item,
      gt_bsak       TYPE TABLE OF ty_bsak,
      gt_with_item2 TYPE TABLE OF ty_with_item2,
      gt_t059z      TYPE TABLE OF ty_t059z,
      gt_lfa1       TYPE TABLE OF ty_lfa1,
      gt_sircar     TYPE TABLE OF zmfit_tipo_sirca,
      gt_report_alv TYPE TABLE OF ty_report_alv,
      gt_fieldcat   TYPE slis_t_fieldcat_alv,
      gt_catalogo   TYPE lvc_t_fcat.

*----------------------------------------------------------------------*
*                     S T R U C T U R E S                              *
*----------------------------------------------------------------------*
DATA: gs_bkpf       TYPE ty_bkpf,
      gs_with_item  TYPE ty_with_item,
      gs_bsak       TYPE ty_bsak,
      gs_with_item2 TYPE ty_with_item2,
      gs_t059z      TYPE ty_t059z,
      gs_lfa1       TYPE ty_lfa1,
      gs_sircar     TYPE zmfit_tipo_sirca,
      gs_report_alv TYPE ty_report_alv,
      gs_layout     TYPE lvc_s_layo.

*----------------------------------------------------------------------*
*                       V A R I A B L E S                              *
*----------------------------------------------------------------------*
DATA: gv_check_error TYPE abap_bool.

*----------------------------------------------------------------------*
*                       C O N S T A N T S                              *
*----------------------------------------------------------------------*
CONSTANTS: gc_charx TYPE c     VALUE 'X',
           gc_ar    TYPE land1 VALUE 'AR',
           gc_catam TYPE zmfit87-provincia VALUE 'Catamarca',
           gc_chaco TYPE zmfit87-provincia VALUE 'Chaco',
           gc_corri TYPE zmfit87-provincia VALUE 'Corrientes',
           gc_jujuy TYPE zmfit87-provincia VALUE 'Jujuy',
           gc_misio TYPE zmfit87-provincia VALUE 'Misiones',
           gc_pampa TYPE zmfit87-provincia VALUE 'La Pampa',
           gc_negro TYPE zmfit87-provincia VALUE 'Rio Negro',
           gc_sjuan TYPE zmfit87-provincia VALUE 'San Juan Teso',
           gc_sluis TYPE zmfit87-provincia VALUE 'San Luis',
           gc_salta TYPE zmfit87-provincia VALUE 'Salta',
           gc_sanfe TYPE zmfit87-provincia VALUE 'Santa Fe',
           gc_santi TYPE zmfit87-provincia VALUE 'Santiago del Estero'.
*** INCLUDE ZMFI_RETENCIONES_SIRCAR_TOP
*** INCLUDE ZMFI_RETENCIONES_SIRCAR_TOP
