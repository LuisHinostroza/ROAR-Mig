FUNCTION-POOL ZMFIT_TIPO_SIRCA           MESSAGE-ID SV.

* INCLUDE LZMFIT_TIPO_SIRCAD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZMFIT_TIPO_SIRCAT00                    . "view rel. data dcl.
