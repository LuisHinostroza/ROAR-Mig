*&---------------------------------------------------------------------*
*& Report  ZFI_RETENCIONES_SIRCAR
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

INCLUDE ZMFI_RETENCIONES_SIRCAR_TOP.
*INCLUDE zfi_retenciones_sircar_top.
INCLUDE ZMFI_RETENCIONES_SIRCAR_SEL.
*INCLUDE zfi_retenciones_sircar_sel.
INCLUDE ZMFI_RETENCIONES_SIRCAR_F01.
*INCLUDE zfi_retenciones_sircar_f01.


*-------------------------------------------------------------- *
*           O B T E N C I Ó N   D E   D A T O S                 *
*-------------------------------------------------------------- *
START-OF-SELECTION.
  PERFORM validate_reten.
  CHECK gv_check_error IS INITIAL.
  PERFORM get_data.
  PERFORM get_alv.
  IF NOT gt_report_alv[] IS INITIAL.
    IF NOT px_file IS INITIAL.
      PERFORM download_file.
    ENDIF.
    PERFORM print.
  ENDIF.
