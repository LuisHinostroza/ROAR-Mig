*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMFIT_SITUAC_IVATOP.              " Global Declarations
  INCLUDE LZMFIT_SITUAC_IVAUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMFIT_SITUAC_IVAF...              " Subroutines
* INCLUDE LZMFIT_SITUAC_IVAO...              " PBO-Modules
* INCLUDE LZMFIT_SITUAC_IVAI...              " PAI-Modules
* INCLUDE LZMFIT_SITUAC_IVAE...              " Events
* INCLUDE LZMFIT_SITUAC_IVAP...              " Local class implement.
* INCLUDE LZMFIT_SITUAC_IVAT99.              " ABAP Unit tests
  INCLUDE LZMFIT_SITUAC_IVAF00                    . " subprograms
  INCLUDE LZMFIT_SITUAC_IVAI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
