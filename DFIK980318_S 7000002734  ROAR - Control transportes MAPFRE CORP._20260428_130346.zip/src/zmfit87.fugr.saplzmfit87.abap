*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMFIT87TOP.                       " Global Declarations
  INCLUDE LZMFIT87UXX.                       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMFIT87F...                       " Subroutines
* INCLUDE LZMFIT87O...                       " PBO-Modules
* INCLUDE LZMFIT87I...                       " PAI-Modules
* INCLUDE LZMFIT87E...                       " Events
* INCLUDE LZMFIT87P...                       " Local class implement.
* INCLUDE LZMFIT87T99.                       " ABAP Unit tests
  INCLUDE LZMFIT87F00                             . " subprograms
  INCLUDE LZMFIT87I00                             . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
