*----------------------------------------------------------------------*
***INCLUDE ZFI_RETENCIONES_IIBB_F.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  F4_HELP_WITHT_LOW
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f4_help_witht_low .

  REFRESH:gt_t059zt,gt_match.

  SELECT witht wt_withcd text40
    FROM t059zt
    INTO TABLE gt_t059zt
    WHERE spras EQ gc_es AND
          land1 EQ gc_ar.

  DELETE gt_t059zt WHERE witht(1) <> 'R'.

  IF gt_t059zt[] IS NOT INITIAL.
    CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
      EXPORTING
        retfield        = 'TEXT40'
        window_title    = 'Indicador para tipo de retenciones'
        value_org       = 'S'
      TABLES
        value_tab       = gt_t059zt
        return_tab      = gt_match
      EXCEPTIONS
        parameter_error = 1
        no_values_found = 2
        OTHERS          = 3.
* Si todo es correcto
    IF sy-subrc EQ 0.
*Leemos lo que obtenermos y se lo pasamos a nuestro parámetro
      READ TABLE gt_match INTO gs_match INDEX 1.
*      MOVE gs_match-fieldval TO s_witht-low.
      READ TABLE gt_t059zt INTO gs_t059zt WITH KEY text40 = gs_match-fieldval.
      MOVE gs_t059zt-wt_withcd TO p_withcd.
      MOVE gs_t059zt-witht TO s_witht-low.

      CALL FUNCTION 'SAPGUI_SET_FUNCTIONCODE'
        EXPORTING
          functioncode           = '/00'
        EXCEPTIONS
          function_not_supported = 1
          OTHERS                 = 2.
      IF sy-subrc <> 0.
* Implement suitable error handling here
      ENDIF.

    ENDIF.
  ENDIF.
ENDFORM.                    " F4_HELP_WITHT_LOW
*&---------------------------------------------------------------------*
*&      Form  F4_HELP_WITHT_LOW
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f4_help_wt_withcd .

  REFRESH:gt_t059zt,gt_match.

  SELECT witht wt_withcd text40
    FROM t059zt
    INTO TABLE gt_t059zt
    WHERE spras EQ gc_es AND
          land1 EQ gc_ar AND
          witht IN s_witht.

  DELETE gt_t059zt WHERE witht(1) <> 'R'.

  IF gt_t059zt[] IS NOT INITIAL.
    CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
      EXPORTING
        retfield        = 'WT_WITHCD'
        window_title    = 'Indicador para tipo de retenciones'
        value_org       = 'S'
      TABLES
        value_tab       = gt_t059zt
        return_tab      = gt_match
      EXCEPTIONS
        parameter_error = 1
        no_values_found = 2
        OTHERS          = 3.
* Si todo es correcto
    IF sy-subrc EQ 0.
*Leemos lo que obtenermos y se lo pasamos a nuestro parámetro
      READ TABLE gt_match INTO gs_match INDEX 1.
      MOVE gs_match-fieldval TO p_withcd.

    ENDIF.
  ENDIF.
ENDFORM.                    " F4_HELP_WITHT_LOW
*** INCLUDE ZMFI_RETENCIONES_IIBB_F
*** INCLUDE ZMFI_RETENCIONES_IIBB_F
