*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZMFIT_TIPO_SIRCATOP.              " Global Declarations
  INCLUDE LZMFIT_TIPO_SIRCAUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZMFIT_TIPO_SIRCAF...              " Subroutines
* INCLUDE LZMFIT_TIPO_SIRCAO...              " PBO-Modules
* INCLUDE LZMFIT_TIPO_SIRCAI...              " PAI-Modules
* INCLUDE LZMFIT_TIPO_SIRCAE...              " Events
* INCLUDE LZMFIT_TIPO_SIRCAP...              " Local class implement.
* INCLUDE LZMFIT_TIPO_SIRCAT99.              " ABAP Unit tests
  INCLUDE LZMFIT_TIPO_SIRCAF00                    . " subprograms
  INCLUDE LZMFIT_TIPO_SIRCAI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
