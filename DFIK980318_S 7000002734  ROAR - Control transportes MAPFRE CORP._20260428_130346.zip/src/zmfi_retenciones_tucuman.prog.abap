*&---------------------------------------------------------------------*
*& Report  ZFI_RETENC_CAPITAL_FEDERAL
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

INCLUDE zmfi_retenciones_tucuman_top.
INCLUDE ZMFI_RETENCIONES_TUCUMAN_SEL.
*INCLUDE zfi_retenciones_tucuman_sel.
INCLUDE ZMFI_RETENCIONES_TUCUMAN_F01.
*INCLUDE zfi_retenciones_tucuman_f01.

*-------------------------------------------------------------- *
*           O B T E N C I Ó N   D E   D A T O S                 *
*-------------------------------------------------------------- *
START-OF-SELECTION.
  PERFORM validate_reten.
  PERFORM get_data.
  PERFORM get_alv.
  IF NOT lt_report_alv[] IS INITIAL.
    IF NOT px_file IS INITIAL.
      PERFORM descargar_fichero_datos.
      PERFORM descargar_fichero_retper.
    ENDIF.
    PERFORM print.
  ENDIF.
