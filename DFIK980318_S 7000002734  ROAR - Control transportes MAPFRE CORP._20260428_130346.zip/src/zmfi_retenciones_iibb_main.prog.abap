*&---------------------------------------------------------------------*
*&  Include           ZFI_RETENCIONES_IIBB_MAIN
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  IF rb_aires IS NOT INITIAL.
    SUBMIT zmfi_retenciones_buenos_aires
     WITH p_bukrs  EQ p_bukrs
     WITH s_belnr  IN s_belnr
     WITH s_gjahr  IN s_gjahr
     WITH p_rldnr  EQ p_rldnr
     WITH s_blart  IN s_blart
     WITH s_budat  IN s_budat
     WITH s_lifnr  IN s_lifnr
     WITH s_witht  IN s_witht
     WITH p_withcd EQ p_withcd
     WITH px_file  EQ px_file
*INI MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
     WITH p_alt    EQ p_alt
     WITH p_baj    EQ p_baj
*FIN MOD Deloitte - CCMIGU5 - 26/11/2025 - S 7000001842: Modificación reporte retenciones IIBB
     AND RETURN.

  ELSEIF rb_capfe IS NOT INITIAL.
    SUBMIT zmfi_retenc_capital_federal
    WITH p_bukrs  EQ p_bukrs
    WITH s_belnr  IN s_belnr
    WITH s_gjahr  IN s_gjahr
    WITH p_rldnr  EQ p_rldnr
    WITH s_blart  IN s_blart
    WITH s_budat  IN s_budat
    WITH s_lifnr  IN s_lifnr
    WITH s_witht  IN s_witht
    WITH p_withcd EQ p_withcd
    WITH px_file  EQ px_file AND RETURN.

  ELSEIF rb_cordo IS NOT INITIAL.
    SUBMIT zmfi_retenciones_cordoba
     WITH p_bukrs  EQ p_bukrs
     WITH s_belnr  IN s_belnr
     WITH s_gjahr  IN s_gjahr
     WITH p_rldnr  EQ p_rldnr
     WITH s_blart  IN s_blart
     WITH s_budat  IN s_budat
     WITH s_lifnr  IN s_lifnr
     WITH s_witht  IN s_witht
     WITH p_withcd EQ p_withcd
     WITH px_file  EQ px_file AND RETURN.

  ELSEIF rb_mendo IS NOT INITIAL.
    SUBMIT zmfi_retenciones_mendoza
     WITH p_bukrs  EQ p_bukrs
     WITH s_belnr  IN s_belnr
     WITH s_gjahr  IN s_gjahr
     WITH p_rldnr  EQ p_rldnr
     WITH s_blart  IN s_blart
     WITH s_budat  IN s_budat
     WITH s_lifnr  IN s_lifnr
     WITH s_witht  IN s_witht
     WITH p_withcd EQ p_withcd
     WITH px_file  EQ px_file AND RETURN.

  ELSEIF rb_tucum IS NOT INITIAL.
    SUBMIT zmfi_retenciones_tucuman
     WITH p_bukrs  EQ p_bukrs
     WITH s_belnr  IN s_belnr
     WITH s_gjahr  IN s_gjahr
     WITH p_rldnr  EQ p_rldnr
     WITH s_blart  IN s_blart
     WITH s_budat  IN s_budat
     WITH s_lifnr  IN s_lifnr
     WITH s_witht  IN s_witht
     WITH p_withcd EQ p_withcd
     WITH px_file  EQ px_file AND RETURN.

  ELSE.
    SUBMIT zmfi_retenciones_sircar
    WITH p_bukrs  EQ p_bukrs
    WITH s_belnr  IN s_belnr
    WITH s_gjahr  IN s_gjahr
    WITH p_rldnr  EQ p_rldnr
    WITH s_blart  IN s_blart
    WITH s_budat  IN s_budat
    WITH s_lifnr  IN s_lifnr
    WITH s_witht  IN s_witht
    WITH p_withcd EQ p_withcd
    WITH px_file  EQ px_file
    WITH rb_catam EQ rb_catam
    WITH rb_chaco EQ rb_chaco
    WITH rb_corri EQ rb_corri
    WITH rb_jujuy EQ rb_jujuy
    WITH rb_misio EQ rb_misio
    WITH rb_pampa EQ rb_pampa
    WITH rb_negro EQ rb_negro
    WITH rb_sjuan EQ rb_sjuan
    WITH rb_sluis EQ rb_sluis
    WITH rb_salta EQ rb_salta
    WITH rb_sanfe EQ rb_sanfe
    WITH rb_santi EQ rb_santi AND RETURN.
  ENDIF.
