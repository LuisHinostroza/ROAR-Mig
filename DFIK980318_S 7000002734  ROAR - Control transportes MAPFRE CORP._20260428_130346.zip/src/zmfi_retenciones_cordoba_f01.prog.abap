*&---------------------------------------------------------------------*
*&      Form  VALIDATE_RETEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM validate_reten .

  CONSTANTS: lc_land1 TYPE land1 VALUE 'AR',
             lc_witht TYPE witht VALUE 'RD'.

  DATA: lv_wt_withcd TYPE wt_withcd,
        lv_message   TYPE string.

  IF s_witht-low <> lc_witht AND  s_witht-low IS NOT INITIAL.
    CONCATENATE 'El tipo de Retención debe ser' lc_witht INTO lv_message SEPARATED BY space.
    MESSAGE lv_message TYPE 'E' DISPLAY LIKE 'E'.
  ELSE.
    IF p_withcd IS NOT INITIAL.
      SELECT SINGLE wt_withcd
        FROM t059z
        INTO @lv_wt_withcd
        WHERE land1     = @lc_land1 AND
              witht     = @lc_witht AND
              wt_withcd = @p_withcd.
      IF sy-subrc <> 0.
        MESSAGE 'El indicador de Retención no es correcto' TYPE 'E' DISPLAY LIKE 'E'.
      ENDIF.

    ENDIF.
  ENDIF.

ENDFORM.                    " VALIDATE_RETEN
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .
  PERFORM cabecera_documentos.
  PERFORM documentos_compensados.
  PERFORM maestro_proveedores.
ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Form  CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM cabecera_documentos .

  SELECT bukrs, belnr, gjahr, budat, bktxt
  FROM bkpf
  INTO TABLE @lt_bkpf
  WHERE bukrs EQ @p_bukrs AND
        belnr IN @s_belnr AND
        gjahr IN @s_gjahr AND
        blart IN @s_blart AND
        budat IN @s_budat AND
        xstov NE @lc_charx.
  IF sy-subrc EQ 0.
    IF NOT p_withcd IS INITIAL.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht      AND
            wt_withcd EQ p_withcd.
    ELSE.
      SELECT bukrs belnr gjahr buzei witht wt_withcd augbl augdt ctnumber wt_qsshh wt_qbshh qsatz
      FROM with_item
      INTO TABLE lt_with_item
      FOR ALL ENTRIES IN lt_bkpf
      WHERE bukrs     EQ lt_bkpf-bukrs AND
            belnr     EQ lt_bkpf-belnr AND
            gjahr     EQ lt_bkpf-gjahr AND
            witht     IN s_witht.
    ENDIF.
  ENDIF.

ENDFORM.                    " CABECERA_DOCUMENTOS
*&---------------------------------------------------------------------*
*&      Form  DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM documentos_compensados .

  IF NOT lt_with_item[] IS INITIAL.
*    SELECT bukrs lifnr augbl gjahr belnr buzei xblnr blart dmbtr
*    FROM bsak
*    INTO TABLE lt_bsak
*    FOR ALL ENTRIES IN lt_with_item
*    WHERE bukrs EQ p_bukrs            AND
*          augbl EQ lt_with_item-belnr AND
*          belnr NE lt_with_item-belnr AND
*          gjahr EQ lt_with_item-gjahr.
*
*    IF sy-subrc EQ 0.
*      IF NOT p_withcd IS INITIAL.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*        FROM with_item
*        INTO TABLE lt_with_item2
*        FOR ALL ENTRIES IN lt_bsak
*        WHERE bukrs     EQ p_bukrs AND
*              belnr     EQ lt_bsak-belnr AND
*              gjahr     EQ lt_bsak-gjahr AND
*              witht     IN s_witht       AND
*              wt_withcd EQ p_withcd.
*      ELSE.
*        SELECT bukrs belnr gjahr buzei witht wt_withcd wt_qsshh wt_qbshh qsatz
*        FROM with_item
*        INTO TABLE lt_with_item2
*        FOR ALL ENTRIES IN lt_bsak
*        WHERE bukrs     EQ p_bukrs AND
*              belnr     EQ lt_bsak-belnr AND
*              gjahr     EQ lt_bsak-gjahr AND
*              witht     IN s_witht.
*      ENDIF.
    SELECT bukrs, lifnr, augbl, gjahr, belnr, buzei, xblnr, blart, dmbtr
      FROM bsak_view
      INTO TABLE @lt_bsak
      FOR ALL ENTRIES IN @lt_with_item
      WHERE bukrs EQ @p_bukrs            AND
            belnr EQ @lt_with_item-belnr AND
            gjahr EQ @lt_with_item-gjahr.
    IF sy-subrc EQ 0.
      SELECT *
      FROM zmfit_concep_ret
      INTO TABLE @lt_concep_reten
      FOR ALL ENTRIES IN @lt_with_item
      WHERE witht     EQ @lt_with_item-witht AND
            wt_withcd EQ @lt_with_item-wt_withcd.
    ENDIF.
  ENDIF.

ENDFORM.                    " DOCUMENTOS_COMPENSADOS
*&---------------------------------------------------------------------*
*&      Form  MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM maestro_proveedores .
  IF NOT lt_bsak[] IS INITIAL.
    SELECT lifnr, name1, regio, adrnr, stcd1, stcd2, fityp, stcdt
    FROM lfa1
    INTO TABLE @lt_lfa1
    FOR ALL ENTRIES IN @lt_bsak
    WHERE lifnr EQ @lt_bsak-lifnr AND
          land1 EQ 'AR'.
    IF sy-subrc EQ 0.
      SELECT addrnumber, city1, post_code1, street, house_num1
      FROM adrc
      INTO TABLE @lt_adrc
      FOR ALL ENTRIES IN @lt_lfa1
      WHERE addrnumber = @lt_lfa1-adrnr.
      IF sy-subrc EQ 0.ENDIF.

      SELECT *
      FROM zmfit_prov_cordo
      INTO TABLE @lt_prov_cordoba
      FOR ALL ENTRIES IN @lt_lfa1
      WHERE region = @lt_lfa1-regio.
    ENDIF.
  ENDIF.
ENDFORM.                    " MAESTRO_PROVEEDORES
*&---------------------------------------------------------------------*
*&      Form  GET_ALV
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_alv .
  DATA:lv_secuencial(8) TYPE n.

*  LOOP AT lt_bsak INTO ls_bsak.
*    ADD 1 TO lv_secuencial.
*    CLEAR:ls_report_alv,ls_with_item,ls_with_item2,
*          ls_lfa1,ls_adrc,ls_prov_cordoba,
*          ls_concep_reten.
*
*    ls_report_alv-belnr = ls_bsak-belnr.                "1-Documento
*    ls_report_alv-xblnr = ls_bsak-xblnr.                "2-Nro. Factura
*    ls_report_alv-lifnr = ls_bsak-lifnr.                "3-Acreedor
*    ls_report_alv-gjahr = ls_bsak-gjahr.                "5-Ejercico
*    ls_report_alv-dmbtr = ls_bsak-dmbtr.                "9-Importe Total
*
*    READ TABLE lt_with_item INTO ls_with_item
*         WITH KEY  bukrs = ls_bsak-bukrs
*                   belnr = ls_bsak-augbl
*                   gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-augdt    = ls_with_item-augdt.      "4-Fecha
*      ls_report_alv-ctnumber = ls_with_item-ctnumber.   "8-Certificado Retención
*    ENDIF.
*
*    READ TABLE lt_lfa1 INTO ls_lfa1
*         WITH KEY lifnr = ls_bsak-lifnr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-stcdt   = ls_lfa1-stcdt.            "6-Tipo NIF
*      ls_report_alv-stcd1   = ls_lfa1-stcd1.            "7-CUIT
*      ls_report_alv-name1   = ls_lfa1-name1.            "15-Nombre
*      ls_report_alv-stcd2   = ls_lfa1-stcd2.            "21-Nro Incripción
*
*      READ TABLE lt_adrc INTO ls_adrc
*           WITH KEY addrnumber = ls_lfa1-adrnr.
*      IF sy-subrc EQ 0.
*        ls_report_alv-street     = ls_adrc-street.      "16-Name
*        ls_report_alv-house_num1 = ls_adrc-house_num1.  "17-Nro
*        ls_report_alv-city1      = ls_adrc-city1.       "18-Localidad
*        ls_report_alv-post_code1 = ls_adrc-post_code1.  "20-Codigo Postal
*      ENDIF.
*
*      READ TABLE lt_prov_cordoba INTO ls_prov_cordoba
*           WITH KEY region = ls_lfa1-regio.
*      IF sy-subrc EQ 0.
*        ls_report_alv-zprov = ls_prov_cordoba-zprov.    "19-Provincia
*      ENDIF.
*    ENDIF.
*
*    READ TABLE lt_with_item2 INTO ls_with_item2
*         WITH KEY bukrs = ls_bsak-bukrs
*                  belnr = ls_bsak-belnr
*                  gjahr = ls_bsak-gjahr.
*    IF sy-subrc EQ 0.
*      ls_report_alv-wt_qsshh  = ls_with_item2-wt_qsshh.  "10-Base del calculo
*      ls_report_alv-qsatz     = ls_with_item2-qsatz.     "11-Alicuota
*      ls_report_alv-wt_qbshh  = ls_with_item2-wt_qbshh.  "12-Monto Retenido
*      ls_report_alv-witht     = ls_with_item2-witht.     "13-Tipo Retención
*      ls_report_alv-wt_withcd = ls_with_item2-wt_withcd. "14-Indicador Retención
*
*      READ TABLE lt_concep_reten INTO ls_concep_reten
*           WITH KEY witht     = ls_with_item2-witht
*                    wt_withcd = ls_with_item2-wt_withcd.
*      IF sy-subrc EQ 0.
*        ls_report_alv-concept_ret = ls_concep_reten-zcodigo. "29-Concepto Retención
*      ENDIF.
*    ENDIF.
*    ls_report_alv-tipo        = 1.                        "21-Tipo
*    ls_report_alv-sector      = space.                    "23-Sector
*    ls_report_alv-torre       = space.                    "24-Torre
*    ls_report_alv-departament = space.                    "25-Departamento
*    ls_report_alv-piso        = space.                    "26-Piso
*    ls_report_alv-identificad = '01'.                     "27-Identificador
*    ls_report_alv-tip_ret     = '1'.                      "28-Tipo Retención
*    ls_report_alv-cod_oper    = lv_secuencial.            "30-Codigo operación
*    APPEND ls_report_alv TO lt_report_alv.
*  ENDLOOP.
  SORT lt_bkpf ASCENDING BY bukrs belnr gjahr.
  SORT lt_lfa1 ASCENDING BY lifnr.
  SORT lt_with_item ASCENDING by bukrs belnr gjahr.
  SORT lt_prov_cordoba ASCENDING BY region.
  SORT lt_adrc ASCENDING BY addrnumber.
  SORT lt_concep_reten ASCENDING BY witht wt_withcd.
  LOOP AT lt_bsak INTO ls_bsak.

    CLEAR: ls_report_alv,ls_with_item,ls_lfa1,ls_adrc,ls_prov_cordoba,ls_concep_reten.

    ls_report_alv-belnr = ls_bsak-belnr.                "1-Documento
    ls_report_alv-lifnr = ls_bsak-lifnr.                "3-Acreedor
    ls_report_alv-gjahr = ls_bsak-gjahr.                "5-Ejercico
    ls_report_alv-dmbtr = ls_bsak-dmbtr.                "9-Importe Total

    READ TABLE lt_bkpf INTO ls_bkpf WITH KEY bukrs = ls_bsak-bukrs
                                             belnr = ls_bsak-belnr
                                             gjahr = ls_bsak-gjahr BINARY SEARCH.
    IF sy-subrc = 0.
      ls_report_alv-xblnr = ls_bkpf-bktxt.              "2-Nro. Factura
    ENDIF.

    READ TABLE lt_with_item INTO ls_with_item
         WITH KEY  bukrs = ls_bsak-bukrs
                   belnr = ls_bsak-augbl
                   gjahr = ls_bsak-gjahr BINARY SEARCH.
    IF sy-subrc EQ 0 AND ls_with_item-ctnumber IS NOT INITIAL.
      ls_report_alv-augdt    = ls_with_item-augdt.      "4-Fecha
      ls_report_alv-ctnumber = ls_with_item-ctnumber.   "8-Certificado Retención
      ls_report_alv-wt_qsshh  = ls_with_item-wt_qsshh.  "10-Base del calculo
      ls_report_alv-qsatz     = ls_with_item-qsatz.     "11-Alicuota
      ls_report_alv-wt_qbshh  = ls_with_item-wt_qbshh.  "12-Monto Retenido
      ls_report_alv-witht     = ls_with_item-witht.     "13-Tipo Retención
      ls_report_alv-wt_withcd = ls_with_item-wt_withcd. "14-Indicador Retención
      READ TABLE lt_concep_reten INTO ls_concep_reten
      WITH KEY witht     = ls_with_item-witht
              wt_withcd = ls_with_item-wt_withcd BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_report_alv-concept_ret = ls_concep_reten-zcodigo. "29-Concepto Retención
      ENDIF.
    ELSE.
      CONTINUE.
    ENDIF.

    READ TABLE lt_lfa1 INTO ls_lfa1
         WITH KEY lifnr = ls_bsak-lifnr BINARY SEARCH.
    IF sy-subrc EQ 0.
      ls_report_alv-stcdt   = ls_lfa1-stcdt.            "6-Tipo NIF
      ls_report_alv-stcd1   = ls_lfa1-stcd1.            "7-CUIT
      ls_report_alv-name1   = ls_lfa1-name1.            "15-Nombre
      ls_report_alv-stcd2   = ls_lfa1-stcd2.            "21-Nro Incripción

      READ TABLE lt_adrc INTO ls_adrc
           WITH KEY addrnumber = ls_lfa1-adrnr BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_report_alv-street     = ls_adrc-street.      "16-Name
        ls_report_alv-house_num1 = ls_adrc-house_num1.  "17-Nro
        ls_report_alv-city1      = ls_adrc-city1.       "18-Localidad
        ls_report_alv-post_code1 = ls_adrc-post_code1.  "20-Codigo Postal
      ENDIF.

      READ TABLE lt_prov_cordoba INTO ls_prov_cordoba
           WITH KEY region = ls_lfa1-regio BINARY SEARCH.
      IF sy-subrc EQ 0.
        ls_report_alv-zprov = ls_prov_cordoba-zprov.    "19-Provincia
      ENDIF.
    ENDIF.

    ADD 1 TO lv_secuencial.
    ls_report_alv-tipo        = 1.                        "21-Tipo
    ls_report_alv-sector      = space.                    "23-Sector
    ls_report_alv-torre       = space.                    "24-Torre
    ls_report_alv-departament = space.                    "25-Departamento
    ls_report_alv-piso        = space.                    "26-Piso
    ls_report_alv-identificad = '01'.                     "27-Identificador
    ls_report_alv-tip_ret     = '1'.                      "28-Tipo Retención
    ls_report_alv-cod_oper    = lv_secuencial.            "30-Codigo operación
    APPEND ls_report_alv TO lt_report_alv.
  ENDLOOP.

ENDFORM.                    " GET_ALV
*&---------------------------------------------------------------------*
*&      Form  PRINT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM print .
  DATA: ls_layout TYPE slis_layout_alv.

  ls_layout-colwidth_optimize = 'X'.

  PERFORM fieldcat_init USING lt_fieldcat[].

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_buffer_active    = 'X'
      i_callback_program = sy-repid
      is_layout          = ls_layout
      it_fieldcat        = lt_fieldcat[]
      i_save             = 'X'
    TABLES
      t_outtab           = lt_report_alv
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.
ENDFORM.                    " PRINT
*&---------------------------------------------------------------------*
*&      Form  FIELDCAT_INIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_FIELDCAT[]  text
*----------------------------------------------------------------------*
FORM fieldcat_init  USING lt_fieldcat TYPE slis_t_fieldcat_alv.

  DATA: ls_fieldcat TYPE slis_fieldcat_alv.
  DATA: lv_linea TYPE i.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'BELNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t01.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'XBLNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t02.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'LIFNR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t03.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'AUGDT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t04.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'GJAHR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t05.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCDT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t06.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t07.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CTNUMBER'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t08.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'DMBTR'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t09.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QSSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t10.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'QSATZ'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t11.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_QBSHH'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t12.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WITHT'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t13.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'WT_WITHCD'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t14.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'NAME1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t15.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STREET'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t16.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'HOUSE_NUM1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t17.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CITY1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t18.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'ZPROV'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t19.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'POST_CODE1'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t20.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'STCD2'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t22.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'TIP_RET'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t28.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'CONCEPT_RET'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t29.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.

  CLEAR ls_fieldcat.
  ADD 1 TO lv_linea.
  ls_fieldcat-fieldname   = 'COD_OPER'.
  ls_fieldcat-tabname     = 'LT_REPORT_ALV'.
  ls_fieldcat-seltext_m   = TEXT-t30.
  ls_fieldcat-col_pos     = lv_linea.
  APPEND ls_fieldcat TO lt_fieldcat.


ENDFORM.                    " FIELDCAT_INIT
*&---------------------------------------------------------------------*
*&      Form  SUBIR_FICHERO_AL11
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM subir_fichero_al11_proveedores.
  DATA: lv_ruta           TYPE localfile VALUE '/tmp/Cordoba_Proveedores.txt',
        lv_string         TYPE string,
        lv_tipo(1)        TYPE c,
        lv_nombre(100)    TYPE c,
        lv_cuit(13)       TYPE c,
        lv_inscri(10)     TYPE n,
        lv_cordoba(1)     TYPE c,
        lv_calle(50)      TYPE c,
        lv_numero(5)      TYPE c,
        lv_sector(4)      TYPE c,
        lv_torre(2)       TYPE c,
        lv_departament(4) TYPE c,
        lv_piso(3)        TYPE c,
        lv_localida(50)   TYPE c,
        lv_cod_postal(8)  TYPE c,
        lv_provincia(2)   TYPE c.

  OPEN DATASET lv_ruta FOR OUTPUT IN TEXT MODE ENCODING DEFAULT.
  LOOP AT lt_report_alv INTO ls_report_alv.
    lv_tipo        = ls_report_alv-tipo.
    lv_nombre      = ls_report_alv-name1.
    lv_cuit        = ls_report_alv-stcd1.
    lv_inscri      = ls_report_alv-stcd2.
    lv_cordoba     = '1'. "o '0'
    lv_calle       = ls_report_alv-street.
    lv_numero      = ls_report_alv-house_num1.
    lv_sector      = ls_report_alv-sector.
    lv_torre       = ls_report_alv-torre.
    lv_departament = ls_report_alv-departament.
    lv_piso        = ls_report_alv-piso.
    lv_localida    = ls_report_alv-city1.
    lv_cod_postal  = ls_report_alv-post_code1.
    lv_provincia   = ls_report_alv-zprov.
    TRANSLATE: lv_tipo        USING ' #',
               lv_nombre      USING ' #',
               lv_cuit        USING ' #',
               lv_calle       USING ' #',
               lv_numero      USING ' #',
               lv_sector      USING ' #',
               lv_torre       USING ' #',
               lv_departament USING ' #',
               lv_piso        USING ' #',
               lv_localida    USING ' #',
               lv_cod_postal  USING ' #',
               lv_provincia   USING ' #'.
    CONCATENATE lv_tipo                   "Tipo
                lv_nombre                 "Apellido/razon Social
                lv_cuit                   "CUIT
                lv_inscri                 "Nº Inscripcion
                lv_cordoba                "Inscrito Cordoba
                lv_calle                  "Calle
                lv_numero                 "Numero
                lv_sector                 "Sector
                lv_torre                  "Torre
                lv_departament            "Departamento
                lv_piso                   "Piso
                lv_localida               "Barrio
                lv_localida               "Localidad
                lv_cod_postal             "CP
                lv_provincia              "Provincia
                INTO lv_string.
    TRANSLATE lv_string USING '# '.
    TRANSFER lv_string TO lv_ruta.
    CLEAR: lv_string,ls_report_alv.
  ENDLOOP.
  CLOSE DATASET lv_ruta.
ENDFORM.                    " SUBIR_FICHERO_AL11
*&---------------------------------------------------------------------*
*&      Form  SUBIR_FICHERO_AL11_RETENCIONES
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM subir_fichero_al11_retenciones .
  DATA: lv_ruta          TYPE localfile VALUE '/tmp/Cordoba_Retenciones.txt',
        lv_string        TYPE string,
        lv_identi(2)     TYPE n,
        lv_cod_op(8)     TYPE n,
        lv_tip_ret(1)    TYPE n,
        lv_concept(2)    TYPE n,
        lv_fecha_r(10)   TYPE c,
        lv_fecha_e(10)   TYPE c,
        lv_num_const(14) TYPE n,
        lv_cuit(13)      TYPE c,
        lv_base(13)      TYPE c,
        lv_alicuota(8)   TYPE c,
        lv_importe(11)   TYPE c,
        lv_count         TYPE i,
        lv_num           TYPE string.

  OPEN DATASET lv_ruta FOR OUTPUT IN TEXT MODE ENCODING DEFAULT.
  LOOP AT lt_report_alv INTO ls_report_alv.
    lv_identi   = ls_report_alv-identificad.
    lv_cod_op   = ls_report_alv-cod_oper.
    lv_tip_ret  = ls_report_alv-tip_ret.
    lv_concept  = ls_report_alv-concept_ret.
    CONCATENATE ls_report_alv-augdt+6(2) '/'
                ls_report_alv-augdt+4(2) '/'
                ls_report_alv-augdt+0(4)
           INTO lv_fecha_r.
    lv_fecha_e  = lv_fecha_r.
*    lv_num_const
    lv_cuit     = ls_report_alv-stcd1.
    lv_base     = ls_report_alv-wt_qsshh."#EC CI_FLDEXT_OK[2610650]
    lv_alicuota = ls_report_alv-qsatz.
    lv_importe  = ls_report_alv-wt_qbshh."#EC CI_FLDEXT_OK[2610650]
    TRANSLATE: lv_num      USING ' #',
               lv_cuit     USING ' #'.

    REPLACE '.' WITH ',' INTO lv_base.
    CONDENSE lv_base.
    lv_num = strlen( lv_base ).
    IF lv_num < 13.
      lv_count = 13 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_base INTO lv_base.
      ENDDO.
    ENDIF.

    REPLACE '.' WITH ',' INTO lv_alicuota.
    CONDENSE lv_alicuota.
    lv_num = strlen( lv_alicuota ).
    IF lv_num < 8.
      lv_count = 8 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_alicuota INTO lv_alicuota.
      ENDDO.
    ENDIF.

    REPLACE '.' WITH ',' INTO lv_importe.
    CONDENSE lv_importe.
    lv_num = strlen( lv_importe ).
    IF lv_num < 11.
      lv_count = 11 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_importe INTO lv_importe.
      ENDDO.
    ENDIF.

    CONCATENATE lv_identi             "Identificador
                lv_cod_op             "Codigo operación
                lv_tip_ret            "Tipo Retención
                lv_concept            "Concepto Retención
                lv_fecha_r            "Fecha retención
                lv_fecha_e            "Fecha Emisión Constancia
                lv_num_const          "Numero Constancia
                lv_cuit               "CUIT
                lv_base               "Base retencion
                lv_alicuota           "Alicuota
                lv_importe            "Importe Retenido
    INTO lv_string.
    TRANSLATE lv_string USING '# '.
    TRANSFER lv_string TO lv_ruta.
    CLEAR: lv_string,ls_report_alv.
  ENDLOOP.
  CLOSE DATASET lv_ruta.
ENDFORM.                    " SUBIR_FICHERO_AL11_RETENCIONES
*&---------------------------------------------------------------------*
*&      Form  DOWNLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM download_file .

  DATA: lv_path            TYPE rlgrap-filename,
        lv_nombre_fichero  TYPE string,
        lv_linea           TYPE string,
        lt_fichero         TYPE STANDARD TABLE OF string,
        lv_count           TYPE i,
        lv_num             TYPE string,
        lv_alic            TYPE dec23_2,
        lv_renglon(5)      TYPE c,         "(1) Renglón, contador
        lv_orig_comp(1)    TYPE c,         "(2) origen comprobante
        lv_type_comp(1)    TYPE c,         "(3) tipo comprobante
        lv_comp(12)        TYPE c,         "(4) comprobante --> valor fijo a "000000000000"
        lv_cuit(11)        TYPE c,         "(5) CUIT
        lv_fecha_r(10)     TYPE c,         "(6) fecha retencion
        lv_base(12)        TYPE c,         "(7) base retencion
        lv_alicuota(6)     TYPE c,         "(8) alicuota
        lv_importe(12)     TYPE c,         "(9) importe retenido --> '7'*'8'/100
        lv_type_ret(3)     TYPE c,         "(10) tipo regimen --> valor parametizable '001'
        lv_jurisdiccion(3) TYPE c,         "(11) jurisdiccion
        lv_operacion(1)    TYPE c,         "(12) tipo operacion
        lv_fecha_e(10)     TYPE c,         "(13) fecha emision  --> igual fecha retencion
        lv_num_const(14)   TYPE c,         "(14) constancia  --> numero comprobante retención
        lv_num_ori(14)     TYPE n.         "(15) constancia original

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    EXPORTING
      program_name  = syst-repid
      dynpro_number = syst-dynnr
    CHANGING
      file_name     = lv_path
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

  LOOP AT lt_report_alv INTO ls_report_alv.
    "Contador = bucle actual del LOOP
    lv_renglon = sy-tabix.
    "Comprobante
    lv_orig_comp = 1.
    lv_type_comp = 1.
    lv_comp = 00000000000.

    "Convertir fecha
    CONCATENATE ls_report_alv-augdt+6(2) '/'
                ls_report_alv-augdt+4(2) '/'
                ls_report_alv-augdt+0(4)
           INTO lv_fecha_r.
    lv_fecha_e  = lv_fecha_r.

    "Sacar datos del ALV
    lv_cuit     = ls_report_alv-stcd1.
    lv_base  = ls_report_alv-wt_qsshh. "#EC CI_FLDEXT_OK[2610650]
    lv_alic = ls_report_alv-qsatz.
    lv_alicuota = lv_alic.
    lv_importe = ls_report_alv-wt_qbshh. "#EC CI_FLDEXT_OK[2610650]
    lv_num_const = ls_report_alv-ctnumber.

    "Datos incognita
    lv_type_ret = 001.
    lv_jurisdiccion = '904'.
    lv_operacion = '1'.

    "Completar con ceros
    CONDENSE lv_renglon.
    lv_num = strlen( lv_renglon ).
    IF lv_num < 5.
      lv_count = 5 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_renglon INTO lv_renglon.
      ENDDO.
    ENDIF.

    CONDENSE lv_comp.
    lv_num = strlen( lv_comp ).
    IF lv_num < 12.
      lv_count = 12 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_comp INTO lv_comp.
      ENDDO.
    ENDIF.

    CONDENSE lv_base.
    SHIFT lv_base RIGHT DELETING TRAILING space.
    CONDENSE lv_alicuota.
    SHIFT lv_alicuota RIGHT DELETING TRAILING space.
    CONDENSE lv_importe.
    SHIFT lv_importe RIGHT DELETING TRAILING space.

    CONDENSE lv_type_ret.
    lv_num = strlen( lv_type_ret ).
    IF lv_num < 3.
      lv_count = 3 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_type_ret INTO lv_type_ret.
      ENDDO.
    ENDIF.

    CONDENSE lv_num_const.
    lv_num = strlen( lv_num_const ).
    IF lv_num < 14.
      lv_count = 14 - lv_num.
      DO lv_count TIMES.
        CONCATENATE '0' lv_num_const INTO lv_num_const.
      ENDDO.
    ENDIF.

    CONCATENATE lv_renglon
                lv_orig_comp
                lv_type_comp
                lv_comp
                lv_cuit
                lv_fecha_r
                lv_base
                lv_alicuota
                lv_importe
                lv_type_ret
                lv_jurisdiccion
                lv_operacion
                lv_fecha_e
                lv_num_const
                lv_num_ori
    INTO lv_linea SEPARATED BY ','.
    APPEND lv_linea TO lt_fichero.
    CLEAR: lv_linea,ls_report_alv.
  ENDLOOP.

  lv_nombre_fichero = lv_path.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename                = lv_nombre_fichero
      filetype                = 'ASC'
      append                  = ''
      write_field_separator   = ''
    TABLES
      data_tab                = lt_fichero
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      OTHERS                  = 22.
  IF sy-subrc <> 0.
* Implement suitable error handling here
  ENDIF.

ENDFORM.                    " DOWNLOAD_FILE
*** INCLUDE ZMFI_RETENCIONES_CORDOBA_F01
*** INCLUDE ZMFI_RETENCIONES_CORDOBA_F01
