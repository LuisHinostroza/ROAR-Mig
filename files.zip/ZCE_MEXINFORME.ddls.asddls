@EndUserText.label: 'Informe FI México'
@ObjectModel.query.implementedBy: 'ABAP:ZCL_MEX_INFORME_QUERY'
@Metadata.allowExtensions: true
define custom entity ZCE_MexInforme
{
      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_CompanyCodeStdVH', element: 'CompanyCode' } }]
  key Sociedad             : bukrs;
  key Ejercicio            : gjahr;
  key NumeroDocumento      : belnr_d;
  key Posicion             : buzei;

      FechaDocumento       : bldat;

      @Consumption.filter: { selectionType: #INTERVAL, mandatory: true }
      FechaContabilizacion : budat;

      Periodo              : monat;
      Referencia           : xblnr1;

      @EndUserText.label: 'Nuevo folio fiscal'
      @EndUserText.quickInfo: 'Folio Fis.'
      NuevoFolioFiscal     : abap.char(255);

      @Semantics.amount.currencyCode: 'MonedaMD'
      ImporteMD            : wrbtr;

      @EndUserText.label: 'Moneda documento'
      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_Currency', element: 'Currency' } }]
      MonedaMD             : waers;

      @Semantics.amount.currencyCode: 'MonedaML'
      ImporteML            : dmbtr;

      @EndUserText.label: 'Moneda local'
      MonedaML             : waers;

      IndicadorIVA         : mwskz;

      @EndUserText.label: 'Importe I.V.A.'
      @EndUserText.quickInfo: 'I.V.A.'
      @Semantics.amount.currencyCode: 'MonedaMD'
      ImporteIVA           : fwste;

      @Semantics.amount.currencyCode: 'MonedaMD'
      Retenciones          : wt_wt1;

      DocCompensacion      : augbl;
      FechaCompensacion    : augdt;

      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_AccountingDocumentType', element: 'AccountingDocumentType' } }]
      ClaseDocumento       : blart;

      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_Supplier_VH', element: 'Supplier' } }]
      Acreedor             : lifnr;

      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_Customer_VH', element: 'Customer' } }]
      Cliente              : kunnr;

      NIFTercero           : stcd1;

      @EndUserText.label: 'Nombre tercero'
      @EndUserText.quickInfo: 'N. tercero'
      NombreTercero        : name1_gp;

      @Consumption.valueHelpDefinition: [{ entity: { name: 'I_Country', element: 'Country' } }]
      PaisTercero          : land1_gp;

      CPTercero            : pstlz;

      @EndUserText.label: 'Cuenta gasto'
      @EndUserText.quickInfo: 'Cta. gasto'
      CuentaGasto          : hkont;

      @EndUserText.label: 'Cuenta I.V.A.'
      @EndUserText.quickInfo: 'Cta. I.V.A'
      CuentaIVA            : hkont;

      Texto                : sgtxt;
      CeCo                 : kostl;
      UsuarioRegistro      : usnam;
}
