# ZMFI_MEX_INFORME → RAP (custom entity) + Fiori Elements

## Orden de creación en ADT

1. **Mensajes en SE91**, clase `ZMFI_MEX_INFORME_MSG` (001 ya existe):
   - `003` No tiene autorización para ninguna sociedad de México
   - `004` Indique la fecha de contabilización
2. **ZCX_MEX_INFORME**: clase de excepción, hereda de `CX_RAP_QUERY_PROVIDER`.
3. **ZCE_MexInforme**: custom entity (Data Definition → plantilla *Define Custom Entity with Parameters*, quitando los parámetros).
   Se activa junto con la clase porque se referencian mutuamente.
4. **ZCL_MEX_INFORME_QUERY**: query provider.
5. **ZCE_MexInforme (DDLX)**: metadata extension.
6. **ZSD_MEX_INFORME**: service definition.
7. **ZSB_MEX_INFORME**: service binding **OData V4 - UI** → *Publish* → *Preview* sobre `MexInforme`.
8. **App**: List Report V4 sobre `ZSB_MEX_INFORME`, mismo proceso que Contrapartida (VS Code + Fiori tools → BSP → `/UI5/UI5_REPOSITORY_LOAD`).

## Qué verificar al activar

- **Value helps**: confirma con Ctrl+Shift+A que existen en tu release `I_CompanyCodeStdVH`, `I_Supplier_VH`, `I_Customer_VH`, `I_AccountingDocumentType`, `I_Currency` e `I_Country`. Si alguna no existe, cambia el nombre o quita la anotación.
- **ZCX_MEX_INFORME**: si ADT marca algo en el constructor (depende de la firma del constructor de `CX_RAP_QUERY_PROVIDER` en tu release), bórralo y deja que ADT lo regenere con Ctrl+1.

## Diferencias contra el reporte

| Punto | Reporte | App |
|---|---|---|
| Moneda local | No existía columna | `MonedaML` (T001-WAERS). Se requiere para la semántica de `ImporteML` y se muestra dentro de la celda del importe |
| Cuenta gasto / CeCo con varias líneas 5* | No determinista (el FOR ALL ENTRIES sin BUZEI deduplica y el orden no es fijo) | La línea 5* con la posición más alta |
| Autorización | Ninguna | `F_BKPF_BUK` actividad 03 por sociedad |
| Filtro folio | Igualdad exacta, sensible a mayúsculas | Cualquier operador de Fiori (contiene, igual, etc.), sin distinguir mayúsculas |
| Sin datos | Mensaje 000 | Tabla vacía |
| Excel | abap2xlsx (`&ZEXCEL`) | Exportación estándar de Fiori (fase 2 si piden el formato idéntico) |

Todo lo demás se replica igual, incluidas las particularidades:
- las posiciones de mayor salen también cuando se filtra solo por acreedor o solo por cliente;
- el IVA se suma a nivel documento y se repite en cada línea;
- la cuenta de IVA es la última.

## Rendimiento

Cada petición de Fiori (cada página al hacer scroll, el conteo y la exportación) vuelve a ejecutar las selecciones completas, porque el query provider no guarda estado. Con la fecha de contabilización obligatoria debería ir bien.

El folio solo se lee para la página visible, salvo que se filtre u ordene por él.

Si con rangos de fecha grandes se siente lento, la mejora siguiente sería un caché en memoria compartida por usuario y filtros.

## Plan de pruebas (ALV vs app)

Con los mismos filtros en ambos, comparar el número de filas y una muestra de importes, IVA, retenciones y folio:

1. Solo el rango de fecha.
2. Fecha y un acreedor. Confirmar que también salen las posiciones de mayor, como en el ALV.
3. Fecha y un cliente.
4. Fecha y un folio completo (debe coincidir con `p_folio`).
5. Un documento con indicador `**` y varios indicadores en BSET.
6. Un documento con retenciones.
7. Un documento con varias líneas de gasto 5*. Aquí puede haber diferencia de cuenta o CeCo por lo explicado arriba.
8. Un usuario sin autorización a alguna sociedad MX. Esa sociedad no debe aparecer.
